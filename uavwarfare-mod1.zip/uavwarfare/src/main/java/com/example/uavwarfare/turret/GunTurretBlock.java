package com.example.uavwarfare.turret;

import com.example.uavwarfare.item.UavItem;
import com.example.uavwarfare.registry.ModItems;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/** Пулемётная турель. ПКМ — сесть за пулемёт (камера мышью, ЛКМ — огонь); ПКМ с патронами — зарядка. */
public class GunTurretBlock extends BlockWithEntity {
    private static final VoxelShape SHAPE = Block.createCuboidShape(2, 0, 2, 14, 12, 14);
    public GunTurretBlock(Settings s) { super(s); }
    @Override public BlockEntity createBlockEntity(BlockView w) { return new GunTurretBlockEntity(); }
    @Override public BlockRenderType getRenderType(BlockState s) { return BlockRenderType.MODEL; }
    @Override public VoxelShape getOutlineShape(BlockState s, BlockView w, BlockPos p, ShapeContext c) { return SHAPE; }

    @Override
    public ActionResult onUse(BlockState st, World w, BlockPos pos, PlayerEntity pl, Hand hand, BlockHitResult hit) {
        if (w.isClient) return ActionResult.SUCCESS;
        BlockEntity be = w.getBlockEntity(pos);
        if (!(be instanceof GunTurretBlockEntity)) return ActionResult.PASS;
        GunTurretBlockEntity t = (GunTurretBlockEntity) be;
        ItemStack held = pl.getStackInHand(hand);
        if (held.getItem() == ModItems.TRACER_AMMO) t.load(held, pl);
        else t.mount((ServerPlayerEntity) pl);
        return ActionResult.CONSUME;
    }
}

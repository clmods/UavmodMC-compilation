package com.example.uavwarfare.client.render;

import com.example.uavwarfare.entity.Afl196Entity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

/** Прямое высокорасположенное крыло, шасси, хвостовая балка с оперением, тянущий винт спереди. */
@Environment(EnvType.CLIENT)
public class Afl196Model extends UavModel<Afl196Entity> {
    public Afl196Model() {
        cube(-4f, -4f, -22f, 8, 8, 40);           // фюзеляж
        cube(-3f, -3f, -29f, 6, 6, 7);            // носовой обтекатель
        cube(-46f, -9f, -8f, 92, 2, 12);          // крыло
        cube(-47f, -19f, -7f, 1, 10, 8);          // законцовки
        cube(46f, -19f, -7f, 1, 10, 8);
        cube(-6f, -7f, -4f, 1, 3, 2);             // подкосы
        cube(5f, -7f, -4f, 1, 3, 2);
        cube(-1.5f, -4f, 18f, 3, 3, 22);          // хвостовая балка
        cube(-14f, -5f, 36f, 28, 1.5f, 8);        // стабилизатор
        cube(-0.75f, -16f, 34f, 1.5f, 12, 8);     // киль
        cube(-0.5f, 4f, -16f, 1, 6, 1);           // шасси: нос
        cube(-1f, 9f, -16.5f, 2, 2, 2);
        cube(-9f, 4f, 0f, 1, 6, 1);               // шасси: основные
        cube(8f, 4f, 0f, 1, 6, 1);
        cube(-9.5f, 9f, -0.5f, 2, 2, 2);
        cube(7.5f, 9f, -0.5f, 2, 2, 2);
        propeller(0f, 0f, -30f);                  // тянущий винт
    }
}

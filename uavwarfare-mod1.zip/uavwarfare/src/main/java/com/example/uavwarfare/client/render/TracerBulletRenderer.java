package com.example.uavwarfare.client.render;

import com.example.uavwarfare.UavWarfare;
import com.example.uavwarfare.entity.TracerBulletEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Matrix4f;
import net.minecraft.util.math.Vec3d;

/** Светящаяся трасса: два скрещённых узких квада вдоль вектора скорости, яркая «голова» → прозрачный «хвост». */
@Environment(EnvType.CLIENT)
public class TracerBulletRenderer extends EntityRenderer<TracerBulletEntity> {
    public TracerBulletRenderer(EntityRenderDispatcher d) { super(d); }
    @Override public Identifier getTexture(TracerBulletEntity e) { return UavWarfare.id("textures/entity/afl196.png"); }

    @Override public void render(TracerBulletEntity e, float yaw, float td, MatrixStack m, VertexConsumerProvider vcp, int light) {
        Vec3d v = e.getVelocity();
        if (v.lengthSquared() < 1e-4) return;
        Vec3d dir = v.normalize();
        Vec3d tail = dir.multiply(-2.5);
        Vec3d up = Math.abs(dir.y) > 0.99 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
        Vec3d p1 = dir.crossProduct(up).normalize().multiply(0.04);
        Vec3d p2 = dir.crossProduct(p1).normalize().multiply(0.04);
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLightning());
        Matrix4f mat = m.peek().getModel();
        quad(vc, mat, tail, p1);
        quad(vc, mat, tail, p2);
    }

    private static void quad(VertexConsumer vc, Matrix4f m, Vec3d tail, Vec3d o) {
        vc.vertex(m, (float) o.x, (float) o.y, (float) o.z).color(255, 210, 90, 255).next();
        vc.vertex(m, (float) -o.x, (float) -o.y, (float) -o.z).color(255, 210, 90, 255).next();
        vc.vertex(m, (float) (tail.x - o.x), (float) (tail.y - o.y), (float) (tail.z - o.z)).color(255, 90, 20, 0).next();
        vc.vertex(m, (float) (tail.x + o.x), (float) (tail.y + o.y), (float) (tail.z + o.z)).color(255, 90, 20, 0).next();
    }
}

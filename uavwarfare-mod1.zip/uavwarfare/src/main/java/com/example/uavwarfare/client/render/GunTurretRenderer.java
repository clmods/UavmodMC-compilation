package com.example.uavwarfare.client.render;

import com.example.uavwarfare.UavWarfare;
import com.example.uavwarfare.turret.GunTurretBlockEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/** Поворотная часть пулемёта. Если за ним сидит игрок — наводится по его взгляду. Ствол откатывается при выстреле. */
@Environment(EnvType.CLIENT)
public class GunTurretRenderer extends BlockEntityRenderer<GunTurretBlockEntity> {
    private static final Identifier TEX = UavWarfare.id("textures/entity/turret.png");
    private final ModelPart body = new ModelPart(64, 64, 0, 0), barrel = new ModelPart(64, 64, 0, 0), shield = new ModelPart(64, 64, 0, 0);

    public GunTurretRenderer(BlockEntityRenderDispatcher d) {
        super(d);
        body.addCuboid(-3f, -3f, -6f, 6, 6, 12);           // Y вверх (без переворота) — центр на оси поворота
        barrel.addCuboid(-1f, -1f, 6f, 2, 2, 22);
        shield.addCuboid(-6f, -5f, 7f, 12, 10, 1);
    }

    @Override public void render(GunTurretBlockEntity be, float td, MatrixStack m, VertexConsumerProvider vcp, int light, int overlay) {
        PlayerEntity p = be.getOperator() == null ? null : be.getWorld().getPlayerByUuid(be.getOperator());
        if (p != null) { be.lastYaw = p.getYaw(td); be.lastPitch = MathHelper.clamp(p.getPitch(td), -80f, 12f); }
        float rec = MathHelper.lerp(td, be.prevRecoil, be.recoil);
        m.push();
        m.translate(0.5, 0.78, 0.5);
        m.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(-be.lastYaw));   // +Z модели = «юг»; yaw 0 смотрит на юг
        m.multiply(Vector3f.POSITIVE_X.getDegreesQuaternion(be.lastPitch));  // pitch>0 — вниз
        net.minecraft.client.render.VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(TEX));
        body.render(m, vc, light, overlay);
        shield.render(m, vc, light, overlay);
        barrel.setPivot(0f, 0f, -rec * 4f);                                  // откат ствола (в пикселях модели)
        barrel.render(m, vc, light, overlay);
        m.pop();
    }
}

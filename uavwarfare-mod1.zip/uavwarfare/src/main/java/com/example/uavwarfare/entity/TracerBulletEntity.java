package com.example.uavwarfare.entity;

import com.example.uavwarfare.config.UavConfig;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Быстрая трассирующая пуля. Рендерится светящейся линией (TracerBulletRenderer). */
public class TracerBulletEntity extends ProjectileEntity {
    public TracerBulletEntity(EntityType<? extends TracerBulletEntity> t, World w) { super(t, w); }
    @Override protected void initDataTracker() {}

    @Override public void tick() {
        super.tick();
        Vec3d v = getVelocity();
        if (!world.isClient) {
            HitResult hit = ProjectileUtil.getCollision(this, e -> !e.isSpectator() && e.isAlive() && e.collides() && e != getOwner());
            if (hit.getType() != HitResult.Type.MISS) { onCollision(hit); return; }
            if (age > 40) { remove(); return; }
        }
        setPosition(getX() + v.x, getY() + v.y, getZ() + v.z);
        setVelocity(v.add(0, -0.01, 0));
    }

    @Override protected void onEntityHit(EntityHitResult r) {
        if (world.isClient) return;
        UavConfig c = UavConfig.get();
        if (r.getEntity() instanceof AbstractUavEntity) {
            ((AbstractUavEntity) r.getEntity()).onTurretHit(c.bulletDamage, r.getPos());   // сценарий A
        } else if (r.getEntity() instanceof LivingEntity) {
            if (!(r.getEntity() instanceof PlayerEntity) || c.turretPvp)
                r.getEntity().damage(DamageSource.thrownProjectile(this, getOwner()), c.bulletDamage);
        }
        remove();
    }

    @Override protected void onBlockHit(BlockHitResult r) {
        if (!world.isClient) ((ServerWorld) world).spawnParticles(ParticleTypes.CRIT, r.getPos().x, r.getPos().y, r.getPos().z, 3, 0.05, 0.05, 0.05, 0.1);
        remove();
    }

    @Override public boolean shouldRender(double d) { return d < 128 * 128; }
    @Override public Packet<?> createSpawnPacket() { return new EntitySpawnS2CPacket(this); }
}

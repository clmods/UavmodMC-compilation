package com.example.uavwarfare.uav;

import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.entity.AbstractUavEntity;
import com.example.uavwarfare.entity.AbstractUavEntity.DeathMode;
import com.example.uavwarfare.block.LauncherBlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.explosion.Explosion;

/** Три сценария гибели: A (турель, 50/50), B (РЭБ, в EwJammer), C (прибытие/удар о землю). */
public final class UavDeathHandler {
    private UavDeathHandler() {}

    /** Сценарий A. Урон накапливается; при превышении прочности — случайно: взрыв в воздухе ИЛИ падение. */
    public static void onTurretHit(AbstractUavEntity u, float dmg, Vec3d hit) {
        if (u.world.isClient || !u.isAlive() || u.isExploding()) return;
        u.addDamage(dmg);
        ServerWorld w = (ServerWorld) u.world;
        w.spawnParticles(ParticleTypes.CRIT, hit.x, hit.y, hit.z, 4, 0.1, 0.1, 0.1, 0.2);
        if (u.getDamageTaken() < u.maxHealth()) return;
        if (u.getDeathMode() == DeathMode.FALL_EXPLODE) return;          // уже падает
        if (w.random.nextFloat() < UavConfig.get().airExplodeChance) explode(u, hit, true);
        else startFall(u);
    }

    /** A2: потеря управления (двигатель глохнет, вращение, дым), взрыв — при ударе о землю. */
    public static void startFall(AbstractUavEntity u) {
        if (u.getDeathMode() == DeathMode.FALL_EXPLODE) return;
        u.applyDeathMode(DeathMode.FALL_EXPLODE);
        u.reportHome(LauncherBlockEntity.ST_DOWN);
        u.world.playSound(null, u.getX(), u.getY(), u.getZ(), SoundEvents.ENTITY_BLAZE_HURT, SoundCategory.NEUTRAL, 2f, 0.6f);
    }

    /** Удар о землю/блок: вода — по конфигу (без разрушений или утопление), иначе взрыв 2 TNT. */
    public static void impact(AbstractUavEntity u) {
        if (u.isExploding() || !u.isAlive()) return;
        explode(u, u.getPos(), true);
    }

    public static void waterImpact(AbstractUavEntity u) {
        if (u.isExploding() || !u.isAlive()) return;
        if (UavConfig.get().waterImpactSinks) {
            u.markExploding();
            u.reportHome(LauncherBlockEntity.ST_DOWN);
            ServerWorld w = (ServerWorld) u.world;
            w.spawnParticles(ParticleTypes.SPLASH, u.getX(), u.getY(), u.getZ(), 40, 0.8, 0.2, 0.8, 0.2);
            w.playSound(null, u.getX(), u.getY(), u.getZ(), SoundEvents.ENTITY_GENERIC_SPLASH, SoundCategory.NEUTRAL, 2f, 0.8f);
            u.remove();
        } else {
            explode(u, u.getPos(), false);   // взрыв без разрушения блоков
        }
    }

    /** Взрыв «N × TNT» + частицы и обломки. Сначала remove(), чтобы дрон не получил урон от собственного взрыва. */
    public static void explode(AbstractUavEntity u, Vec3d at, boolean allowBlocks) {
        if (u.world.isClient || u.markExploding()) return;
        ServerWorld w = (ServerWorld) u.world;
        UavConfig c = UavConfig.get();
        u.reportHome(LauncherBlockEntity.ST_DOWN);
        u.remove();
        Explosion.DestructionType dt = (allowBlocks && c.blockDamage) ? Explosion.DestructionType.BREAK : Explosion.DestructionType.NONE;
        for (int i = 0; i < c.tntCount; i++) w.createExplosion(u, at.x, at.y, at.z, c.tntPower, dt);
        w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, at.x, at.y, at.z, 1, 0, 0, 0, 0);
        w.spawnParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 40, 1.0, 0.6, 1.0, 0.08);
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, at.x, at.y, at.z, 30, 1.2, 0.8, 1.2, 0.05);
        w.spawnParticles(new ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(Items.IRON_NUGGET)),
                at.x, at.y, at.z, 50, 0.7, 0.5, 0.7, 0.35);   // обломки
    }
}

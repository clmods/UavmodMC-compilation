package com.example.uavwarfare.ew;

import com.example.uavwarfare.entity.AbstractUavEntity;
import com.example.uavwarfare.entity.AbstractUavEntity.DeathMode;
import com.example.uavwarfare.block.LauncherBlockEntity;
import com.example.uavwarfare.registry.ModParticles;
import net.minecraft.server.world.ServerWorld;

/** Сценарий B: связь потеряна → навигация выключена → управляемое снижение → взрыв на земле. */
public final class EwJammer {
    private EwJammer() {}
    public static boolean jam(AbstractUavEntity u) {
        if (u.world.isClient || !u.isAlive() || u.getDeathMode() != DeathMode.NONE) return false;
        u.applyDeathMode(DeathMode.JAM_DESCEND);
        u.reportHome(LauncherBlockEntity.ST_DOWN);
        ((ServerWorld) u.world).spawnParticles(ModParticles.JAM, u.getX(), u.getY() + 0.3, u.getZ(), 25, 0.8, 0.4, 0.8, 0.05);
        return true;
    }
}

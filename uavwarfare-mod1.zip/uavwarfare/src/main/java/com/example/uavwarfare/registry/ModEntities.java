package com.example.uavwarfare.registry;

import com.example.uavwarfare.UavWarfare;
import com.example.uavwarfare.entity.*;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.util.registry.Registry;

public class ModEntities {
    public static EntityType<Afl196Entity> AFL196;
    public static EntityType<Shahed136Entity> SHAHED136;
    public static EntityType<TracerBulletEntity> TRACER;
    public static EntityType<TurretSeatEntity> SEAT;

    public static void register() {
        AFL196 = Registry.register(Registry.ENTITY_TYPE, UavWarfare.id("afl196"),
                FabricEntityTypeBuilder.<Afl196Entity>create(SpawnGroup.MISC, Afl196Entity::new)
                        .dimensions(EntityDimensions.fixed(2.6f, 0.6f)).trackRangeBlocks(256)
                        .trackedUpdateRate(1).forceTrackedVelocityUpdates(true).fireImmune().build());
        SHAHED136 = Registry.register(Registry.ENTITY_TYPE, UavWarfare.id("shahed136"),
                FabricEntityTypeBuilder.<Shahed136Entity>create(SpawnGroup.MISC, Shahed136Entity::new)
                        .dimensions(EntityDimensions.fixed(2.2f, 0.5f)).trackRangeBlocks(256)
                        .trackedUpdateRate(1).forceTrackedVelocityUpdates(true).fireImmune().build());
        TRACER = Registry.register(Registry.ENTITY_TYPE, UavWarfare.id("tracer_bullet"),
                FabricEntityTypeBuilder.<TracerBulletEntity>create(SpawnGroup.MISC, TracerBulletEntity::new)
                        .dimensions(EntityDimensions.fixed(0.2f, 0.2f)).trackRangeBlocks(128)
                        .trackedUpdateRate(20).forceTrackedVelocityUpdates(true).build());
        SEAT = Registry.register(Registry.ENTITY_TYPE, UavWarfare.id("turret_seat"),
                FabricEntityTypeBuilder.<TurretSeatEntity>create(SpawnGroup.MISC, TurretSeatEntity::new)
                        .dimensions(EntityDimensions.fixed(0.1f, 0.1f)).trackRangeBlocks(64).build());
    }
}

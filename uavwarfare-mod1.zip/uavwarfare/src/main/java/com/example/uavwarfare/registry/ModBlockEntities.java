package com.example.uavwarfare.registry;

import com.example.uavwarfare.UavWarfare;
import com.example.uavwarfare.block.LauncherBlockEntity;
import com.example.uavwarfare.turret.GunTurretBlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.util.registry.Registry;

public class ModBlockEntities {
    public static BlockEntityType<LauncherBlockEntity> LAUNCHER;
    public static BlockEntityType<GunTurretBlockEntity> TURRET;
    public static void register() {
        LAUNCHER = Registry.register(Registry.BLOCK_ENTITY_TYPE, UavWarfare.id("launcher"),
                BlockEntityType.Builder.create(LauncherBlockEntity::new, ModBlocks.LAUNCHER).build(null));
        TURRET = Registry.register(Registry.BLOCK_ENTITY_TYPE, UavWarfare.id("gun_turret"),
                BlockEntityType.Builder.create(GunTurretBlockEntity::new, ModBlocks.TURRET).build(null));
    }
}

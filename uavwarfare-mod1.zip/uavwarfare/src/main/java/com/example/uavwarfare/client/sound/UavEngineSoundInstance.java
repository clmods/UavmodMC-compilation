package com.example.uavwarfare.client.sound;

import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.entity.AbstractUavEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.Vec3d;

/**
 * Зацикленный звук двигателя. Громкость считаем сами (AttenuationType.NONE — ванильный радиус 16 блоков не подходит),
 * каждый тик подтягиваем к целевой через lerp ≈0.1 → без щелчков. После гибели дрона звук не обрывается,
 * а гаснет 1–2 с.
 */
@Environment(EnvType.CLIENT)
public class UavEngineSoundInstance extends MovingSoundInstance {
    private final AbstractUavEntity uav;
    private float cur = 0f, fade = 1f;
    private double lx, ly, lz;

    public UavEngineSoundInstance(AbstractUavEntity uav) {
        super(uav.engineSound(), SoundCategory.NEUTRAL);
        this.uav = uav;
        this.repeat = true;
        this.repeatDelay = 0;
        this.volume = 0.0001f;
        this.attenuationType = SoundInstance.AttenuationType.NONE;
        lx = uav.getX(); ly = uav.getY(); lz = uav.getZ();
    }

    @Override public void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || uav.world != mc.world) { setDone(); return; }
        UavConfig c = UavConfig.get();
        float gain = 1f;
        if (uav.isAlive()) {
            lx = uav.getX(); ly = uav.getY(); lz = uav.getZ();
            gain = uav.engineGain();
        } else {
            fade -= 1f / (20f * c.soundDeathFadeSeconds);
            if (fade <= 0f) { setDone(); return; }
        }
        this.x = lx; this.y = ly; this.z = lz;
        double d = mc.gameRenderer.getCamera().getPos().distanceTo(new Vec3d(lx, ly, lz));
        float target = SoundManager.volumeAt(d) * gain;
        cur += (target - cur) * c.soundLerp;
        this.volume = Math.max(0.0001f, cur * SoundManager.smoothstep(fade));
        float pt = SoundManager.pitchAt(d) + uav.soundPitchWobble();
        this.pitch += (pt - this.pitch) * c.soundLerp;
    }
}

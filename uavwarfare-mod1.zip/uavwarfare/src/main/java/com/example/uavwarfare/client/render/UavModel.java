package com.example.uavwarfare.client.render;

import com.example.uavwarfare.entity.AbstractUavEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;

/** Базовая «кубическая» модель. Пространство модели как у ванили: Y вниз, нос в −Z. */
@Environment(EnvType.CLIENT)
public abstract class UavModel<T extends AbstractUavEntity> extends EntityModel<T> {
    protected final ModelPart root = new ModelPart(this);
    protected ModelPart prop;
    protected float propSpin = 45f;

    protected UavModel() { textureWidth = 256; textureHeight = 256; }

    protected void cube(float x, float y, float z, float w, float h, float d) {
        ModelPart p = new ModelPart(this);
        p.addCuboid(x, y, z, w, h, d);
        root.addChild(p);
    }
    protected ModelPart propeller(float px, float py, float pz) {
        prop = new ModelPart(this);
        prop.setPivot(px, py, pz);
        prop.addCuboid(-1f, -13f, -0.5f, 2f, 26f, 1f);
        prop.addCuboid(-0.8f, -1f, -2f, 1.6f, 2f, 4f);   // втулка
        root.addChild(prop);
        return prop;
    }
    @Override public void setAngles(T e, float limbAngle, float limbDistance, float anim, float headYaw, float headPitch) {
        if (prop != null) prop.roll = (float) Math.toRadians(anim * e.propSpin());
    }
    @Override public void render(MatrixStack m, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(m, vc, light, overlay, r, g, b, a);
    }
}

package com.example.uavwarfare.registry;

import com.example.uavwarfare.UavWarfare;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.particle.DefaultParticleType;
import net.minecraft.util.registry.Registry;

public class ModParticles {
    public static DefaultParticleType JAM;
    public static void register() {
        JAM = Registry.register(Registry.PARTICLE_TYPE, UavWarfare.id("jam"), FabricParticleTypes.simple());
    }
}

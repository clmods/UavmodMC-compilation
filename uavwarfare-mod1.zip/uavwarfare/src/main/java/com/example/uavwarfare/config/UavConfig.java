package com.example.uavwarfare.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Все числа мода. Файл: config/uavwarfare.json (создаётся при первом запуске). */
public class UavConfig {
    // ---- Управление / карта ----
    public double signalRange = 60;          // радиус связи пульт↔дрон (блоков)
    public double maxFlightRange = 1000;     // макс. удаление путевой точки от пульта (MAX_CONTROL_RANGE)
    public int mapSize = 1000;               // сторона карты в блоках
    public int mapBlocksPerPixel = 4;        // масштаб текстуры карты
    public boolean rthOnSignalLoss = true;   // true = RTH, false = падение
    public int signalLossGraceTicks = 60;
    public double arriveRadius = 5;          // радиус «прибытия» на точку
    public double cruiseHeight = 60;         // высота крейсерского полёта над стартом
    public boolean chunkLoading = true;      // держать чанки вокруг дрона загруженными

    // ---- Взрыв ----
    public int tntCount = 2;                 // «2 TNT»: два взрыва мощностью tntPower
    public float tntPower = 4.0f;            // сила одного TNT
    public boolean blockDamage = true;
    public boolean waterImpactSinks = false; // false: взрыв без разрушения блоков, true: тонет без взрыва

    // ---- Дроны ----
    public float aflHealth = 80f, shahedHealth = 50f;
    public float aflSpeed = 2.0f, shahedSpeed = 1.4f;   // блоков/тик
    public float airExplodeChance = 0.5f;               // сценарий A: шанс взрыва в воздухе (иначе падение)

    // ---- РЭБ ----
    public double ewRadius = 64;
    public int ewCooldownTicks = 400;        // ~20 c
    public int ewActiveTicks = 60;           // сколько тиков AUTO-режим «светит» после активации

    // ---- Турель ----
    public float bulletDamage = 5f, bulletSpeed = 6f, bulletSpread = 0.012f;
    public int fireDelayTicks = 2;
    public float heatPerShot = 1.6f, heatCooling = 0.7f, heatRecover = 40f;
    public int ammoPerItem = 16, ammoCapacity = 500;
    public boolean turretPvp = false;

    // ---- Звук ----
    public double soundMaxRadius = 200, soundFadeZone = 20;
    public float soundLerp = 0.1f, soundDeathFadeSeconds = 1.5f;
    public double[] soundDist = {0, 50, 100, 150, 200};
    public float[] soundVol = {1.0f, 0.75f, 0.4f, 0.15f, 0.05f};

    private static UavConfig instance = new UavConfig();
    public static UavConfig get() { return instance; }

    public static void load() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Path path = FabricLoader.getInstance().getConfigDir().resolve("uavwarfare.json");
        try {
            if (Files.exists(path)) {
                instance = gson.fromJson(new String(Files.readAllBytes(path), StandardCharsets.UTF_8), UavConfig.class);
                if (instance == null) instance = new UavConfig();
            }
            Files.write(path, gson.toJson(instance).getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            System.err.println("[uavwarfare] config error: " + e);
        }
    }
}

package com.example.uavwarfare.registry;

import com.example.uavwarfare.UavWarfare;
import com.example.uavwarfare.block.LauncherBlock;
import com.example.uavwarfare.turret.GunTurretBlock;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.Material;
import net.minecraft.util.registry.Registry;

public class ModBlocks {
    public static Block LAUNCHER, TURRET;
    public static void register() {
        LAUNCHER = Registry.register(Registry.BLOCK, UavWarfare.id("launcher"),
                new LauncherBlock(FabricBlockSettings.of(Material.METAL).strength(3.0f).nonOpaque()));
        TURRET = Registry.register(Registry.BLOCK, UavWarfare.id("gun_turret"),
                new GunTurretBlock(FabricBlockSettings.of(Material.METAL).strength(3.0f).nonOpaque()));
    }
}

package com.example.uavwarfare.client;

import com.example.uavwarfare.client.screen.EwDeviceScreen;
import com.example.uavwarfare.client.sound.UavEngineSoundInstance;
import com.example.uavwarfare.entity.AbstractUavEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;

/** Единственная точка входа из общего кода в клиентские классы (чтобы сервер их не грузил). */
@Environment(EnvType.CLIENT)
public final class ClientHooks {
    private ClientHooks() {}
    public static void startEngineSound(AbstractUavEntity e) {
        MinecraftClient.getInstance().getSoundManager().play(new UavEngineSoundInstance(e));
    }
    public static void openEwScreen() { MinecraftClient.getInstance().openScreen(new EwDeviceScreen()); }
}

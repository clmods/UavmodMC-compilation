package com.example.uavwarfare.network;

import com.example.uavwarfare.UavWarfare;
import com.example.uavwarfare.block.LauncherBlockEntity;
import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.entity.AbstractUavEntity;
import com.example.uavwarfare.ew.EwDeviceItem;
import com.example.uavwarfare.ew.EwJammer;
import com.example.uavwarfare.ew.EwMode;
import com.example.uavwarfare.item.ControllerItem;
import com.example.uavwarfare.item.LauncherLinkManager;
import com.example.uavwarfare.turret.GunTurretBlockEntity;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.UUID;

public final class UavNetworking {
    private UavNetworking() {}
    // S2C
    public static final Identifier CTRL_OPEN = UavWarfare.id("ctrl_open"), CTRL_STATE = UavWarfare.id("ctrl_state"),
            TURRET_STATE = UavWarfare.id("turret_state"), TURRET_SHOT = UavWarfare.id("turret_shot");
    // C2S
    public static final Identifier CTRL_REQUEST = UavWarfare.id("ctrl_request"), CTRL_WAYPOINT = UavWarfare.id("ctrl_wp"),
            CTRL_LAUNCH = UavWarfare.id("ctrl_launch"), CTRL_RTH = UavWarfare.id("ctrl_rth"),
            EW_MODE = UavWarfare.id("ew_mode"), EW_JAM = UavWarfare.id("ew_jam"), TURRET_FIRE = UavWarfare.id("turret_fire");

    public static ItemStack findController(ServerPlayerEntity p) {
        if (p.getMainHandStack().getItem() instanceof ControllerItem) return p.getMainHandStack();
        if (p.getOffHandStack().getItem() instanceof ControllerItem) return p.getOffHandStack();
        return null;
    }
    private static String dim(ServerPlayerEntity p) { return p.world.getRegistryKey().getValue().toString(); }

    /** Состояние вкладок для GUI: по каждой привязанной установке — статус, тип, позиция дрона, точка, прочность, связь. */
    public static PacketByteBuf buildState(ServerPlayerEntity p, ItemStack ctrl) {
        PacketByteBuf b = PacketByteBufs.create();
        List<BlockPos> links = LauncherLinkManager.getLinks(ctrl, dim(p));
        b.writeInt(links.size());
        for (BlockPos pos : links) {
            int status = LauncherBlockEntity.ST_OFFLINE, type = 0;
            Vec3d dp = Vec3d.ZERO; boolean hasWp = false, sig = false; double wx = 0, wz = 0; float hp = 1f;
            if (p.world.isChunkLoaded(pos)) {
                BlockEntity be = p.world.getBlockEntity(pos);
                if (be instanceof LauncherBlockEntity) {
                    LauncherBlockEntity l = (LauncherBlockEntity) be;
                    status = l.status(); type = l.typeId();
                    if (status == LauncherBlockEntity.ST_FLIGHT && l.getDroneUuid() != null) {
                        Entity e = ((ServerWorld) p.world).getEntity(l.getDroneUuid());
                        if (e instanceof AbstractUavEntity) {
                            AbstractUavEntity u = (AbstractUavEntity) e;
                            dp = u.getPos(); hp = u.getHealthFraction();
                            hasWp = u.getWaypoint() != null;
                            if (hasWp) { wx = u.getWaypoint().x; wz = u.getWaypoint().z; }
                            sig = u.squaredDistanceTo(p) <= UavConfig.get().signalRange * UavConfig.get().signalRange;
                        }
                    }
                } else status = LauncherBlockEntity.ST_OFFLINE;
            }
            b.writeBlockPos(pos); b.writeInt(status); b.writeInt(type);
            b.writeDouble(dp.x); b.writeDouble(dp.y); b.writeDouble(dp.z);
            b.writeBoolean(hasWp); b.writeDouble(wx); b.writeDouble(wz); b.writeFloat(hp); b.writeBoolean(sig);
        }
        return b;
    }

    private static LauncherBlockEntity launcher(ServerPlayerEntity p, ItemStack s, int idx) {
        List<BlockPos> l = LauncherLinkManager.getLinks(s, dim(p));
        if (idx < 0 || idx >= l.size() || !p.world.isChunkLoaded(l.get(idx))) return null;
        BlockEntity be = p.world.getBlockEntity(l.get(idx));
        return be instanceof LauncherBlockEntity ? (LauncherBlockEntity) be : null;
    }

    /** Дрон в полёте + проверка связи (60 блоков). null и сообщение игроку, если нельзя. */
    private static AbstractUavEntity controllable(ServerPlayerEntity p, int idx) {
        ItemStack s = findController(p);
        LauncherBlockEntity l = s == null ? null : launcher(p, s, idx);
        if (l == null || l.status() != LauncherBlockEntity.ST_FLIGHT || l.getDroneUuid() == null) {
            p.sendMessage(new TranslatableText("msg.uavwarfare.not_in_flight"), true); return null;
        }
        Entity e = ((ServerWorld) p.world).getEntity(l.getDroneUuid());
        if (!(e instanceof AbstractUavEntity)) { p.sendMessage(new TranslatableText("msg.uavwarfare.not_in_flight"), true); return null; }
        double r = UavConfig.get().signalRange;
        if (e.squaredDistanceTo(p) > r * r) { p.sendMessage(new TranslatableText("msg.uavwarfare.no_signal"), true); return null; }
        return (AbstractUavEntity) e;
    }

    public static void registerServer() {
        ServerPlayNetworking.registerGlobalReceiver(CTRL_REQUEST, (srv, p, h, buf, rs) -> srv.execute(() -> {
            ItemStack s = findController(p);
            if (s != null) ServerPlayNetworking.send(p, CTRL_STATE, buildState(p, s));
        }));

        ServerPlayNetworking.registerGlobalReceiver(CTRL_WAYPOINT, (srv, p, h, buf, rs) -> {
            int idx = buf.readInt(), ox = buf.readInt(), oz = buf.readInt();
            double wx = buf.readDouble(), wz = buf.readDouble();
            srv.execute(() -> {
                UavConfig c = UavConfig.get();
                double half = c.mapSize / 2.0;
                // Граница: внутри карты (квадрат c.mapSize вокруг origin) И не дальше maxFlightRange от пульта.
                boolean inMap = Math.abs(wx - (ox + half)) <= half + 1 && Math.abs(wz - (oz + half)) <= half + 1;
                boolean inRange = Math.hypot(wx - p.getX(), wz - p.getZ()) <= c.maxFlightRange;
                if (!inMap || !inRange) { p.sendMessage(new TranslatableText("msg.uavwarfare.out_of_range"), true); return; }
                AbstractUavEntity u = controllable(p, idx);
                if (u != null) u.setWaypoint(wx, wz);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(CTRL_LAUNCH, (srv, p, h, buf, rs) -> {
            int idx = buf.readInt();
            srv.execute(() -> {
                ItemStack s = findController(p);
                LauncherBlockEntity l = s == null ? null : launcher(p, s, idx);
                if (l != null && l.status() == LauncherBlockEntity.ST_GROUND) l.launch((ServerWorld) p.world);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(CTRL_RTH, (srv, p, h, buf, rs) -> {
            int idx = buf.readInt();
            srv.execute(() -> { AbstractUavEntity u = controllable(p, idx); if (u != null) u.commandRth(); });
        });

        ServerPlayNetworking.registerGlobalReceiver(EW_MODE, (srv, p, h, buf, rs) -> {
            boolean manual = buf.readBoolean();
            srv.execute(() -> {
                ItemStack s = EwDeviceItem.find(p);
                if (s != null) EwDeviceItem.setMode(s, manual ? EwMode.MANUAL : EwMode.AUTO);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(EW_JAM, (srv, p, h, buf, rs) -> {
            UUID id = buf.readUuid();
            srv.execute(() -> {
                ItemStack s = EwDeviceItem.find(p);
                if (s == null) return;
                Entity e = ((ServerWorld) p.world).getEntity(id);
                if (e instanceof AbstractUavEntity) EwDeviceItem.manualJam(p, s, (AbstractUavEntity) e);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(TURRET_FIRE, (srv, p, h, buf, rs) -> srv.execute(() -> {
            if (p.getVehicle() instanceof com.example.uavwarfare.entity.TurretSeatEntity) {
                BlockPos pos = ((com.example.uavwarfare.entity.TurretSeatEntity) p.getVehicle()).getTurretPos();
                if (pos != null && p.world.isChunkLoaded(pos)) {
                    BlockEntity be = p.world.getBlockEntity(pos);
                    if (be instanceof GunTurretBlockEntity) ((GunTurretBlockEntity) be).tryFire(p);
                }
            }
        }));
    }
}

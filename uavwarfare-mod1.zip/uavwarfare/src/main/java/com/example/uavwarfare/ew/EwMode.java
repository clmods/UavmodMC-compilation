package com.example.uavwarfare.ew;

public enum EwMode { AUTO, MANUAL }

package com.example.uavwarfare.client;

import com.example.uavwarfare.UavWarfare;
import com.example.uavwarfare.client.render.*;
import com.example.uavwarfare.client.screen.ControllerScreen;
import com.example.uavwarfare.entity.TurretSeatEntity;
import com.example.uavwarfare.ew.EwDeviceItem;
import com.example.uavwarfare.network.UavNetworking;
import com.example.uavwarfare.registry.*;
import com.example.uavwarfare.turret.GunTurretBlockEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendereregistry.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendereregistry.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.object.builder.v1.client.model.FabricModelPredicateProviderRegistry;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.particle.EndRodParticle;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class UavWarfareClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.INSTANCE.register(ModEntities.AFL196, (d, c) -> new UavRenderer<>(d, new Afl196Model(), "afl196"));
        EntityRendererRegistry.INSTANCE.register(ModEntities.SHAHED136, (d, c) -> new UavRenderer<>(d, new Shahed136Model(), "shahed136"));
        EntityRendererRegistry.INSTANCE.register(ModEntities.TRACER, (d, c) -> new TracerBulletRenderer(d));
        EntityRendererRegistry.INSTANCE.register(ModEntities.SEAT, (d, c) -> new EmptyRenderer(d));
        BlockEntityRendererRegistry.INSTANCE.register(ModBlockEntities.LAUNCHER, LauncherRenderer::new);
        BlockEntityRendererRegistry.INSTANCE.register(ModBlockEntities.TURRET, GunTurretRenderer::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.JAM, EndRodParticle.Factory::new);

        // Подсветка РЭБ: «ready» = 1, на кулдауне 0 (см. models/item/ew_kit.json overrides).
        FabricModelPredicateProviderRegistry.register(ModItems.EW_KIT, UavWarfare.id("ready"), (stack, world, entity) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            return mc.world != null && EwDeviceItem.ready(stack, mc.world.getTime()) ? 1f : 0f;
        });

        // ---- пакеты S2C ----
        ClientPlayNetworking.registerGlobalReceiver(UavNetworking.CTRL_OPEN, (mc, h, buf, rs) -> {
            List<ControllerScreen.Info> l = readInfos(buf);
            mc.execute(() -> mc.openScreen(new ControllerScreen(l)));
        });
        ClientPlayNetworking.registerGlobalReceiver(UavNetworking.CTRL_STATE, (mc, h, buf, rs) -> {
            List<ControllerScreen.Info> l = readInfos(buf);
            mc.execute(() -> { if (mc.currentScreen instanceof ControllerScreen) ((ControllerScreen) mc.currentScreen).setInfos(l); });
        });
        ClientPlayNetworking.registerGlobalReceiver(UavNetworking.TURRET_STATE, (mc, h, buf, rs) -> {
            BlockPos p = buf.readBlockPos(); int ammo = buf.readInt(); float heat = buf.readFloat(); boolean ov = buf.readBoolean();
            mc.execute(() -> { ClientTurretState.pos = p; ClientTurretState.ammo = ammo; ClientTurretState.heat = heat; ClientTurretState.overheated = ov; ClientTurretState.lastUpdate = 0; });
        });
        ClientPlayNetworking.registerGlobalReceiver(UavNetworking.TURRET_SHOT, (mc, h, buf, rs) -> {
            BlockPos p = buf.readBlockPos();
            mc.execute(() -> {
                if (mc.world == null) return;
                BlockEntity be = mc.world.getBlockEntity(p);
                if (be instanceof GunTurretBlockEntity) ((GunTurretBlockEntity) be).recoil = 1f;          // откат ствола
                ClientPlayerEntity pl = mc.player;
                if (pl != null && pl.getVehicle() instanceof TurretSeatEntity && p.equals(((TurretSeatEntity) pl.getVehicle()).getTurretPos())) {
                    pl.pitch -= 0.8f + pl.getRandom().nextFloat() * 0.7f;                                    // отдача камеры
                    pl.yaw += (pl.getRandom().nextFloat() - 0.5f) * 1.0f;
                }
            });
        });

        // ---- ввод стрелка + лимиты камеры + раскачка прицела от нагрева ----
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ClientPlayerEntity p = mc.player;
            if (p == null) return;
            if (p.getVehicle() instanceof TurretSeatEntity) {
                p.pitch = MathHelper.clamp(p.pitch, -80f, 12f);
                if (mc.currentScreen == null && mc.options.keyAttack.isPressed()) ClientPlayNetworking.send(UavNetworking.TURRET_FIRE, PacketByteBufs.create());
                float sway = ClientTurretState.heat * 0.004f;
                p.yaw += (float) Math.sin(p.age * 0.7) * sway;
                p.pitch += (float) Math.cos(p.age * 0.5) * sway;
                ClientTurretState.lastUpdate++;
            } else ClientTurretState.pos = null;
        });

        // ---- HUD прицела ----
        HudRenderCallback.EVENT.register((ms, td) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || !(mc.player.getVehicle() instanceof TurretSeatEntity) || ClientTurretState.pos == null) return;
            int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
            int col = ClientTurretState.overheated ? 0xFFFF3030 : 0xFF50FF50;
            net.minecraft.client.gui.DrawableHelper.fill(ms, w / 2 - 12, h / 2, w / 2 - 4, h / 2 + 1, col);
            net.minecraft.client.gui.DrawableHelper.fill(ms, w / 2 + 4, h / 2, w / 2 + 12, h / 2 + 1, col);
            net.minecraft.client.gui.DrawableHelper.fill(ms, w / 2, h / 2 - 12, w / 2 + 1, h / 2 - 4, col);
            net.minecraft.client.gui.DrawableHelper.fill(ms, w / 2, h / 2 + 4, w / 2 + 1, h / 2 + 12, col);
            String s = "AMMO " + ClientTurretState.ammo + "   HEAT " + (int) ClientTurretState.heat + "%" + (ClientTurretState.overheated ? "  OVERHEAT" : "");
            mc.textRenderer.drawWithShadow(ms, s, w / 2f - mc.textRenderer.getWidth(s) / 2f, h - 60, col);
        });
    }

    private static List<ControllerScreen.Info> readInfos(PacketByteBuf b) {
        int n = b.readInt();
        List<ControllerScreen.Info> l = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            ControllerScreen.Info in = new ControllerScreen.Info();
            in.pos = b.readBlockPos(); in.status = b.readInt(); in.type = b.readInt();
            in.drone = new net.minecraft.util.math.Vec3d(b.readDouble(), b.readDouble(), b.readDouble());
            in.hasWp = b.readBoolean(); in.wx = b.readDouble(); in.wz = b.readDouble(); in.hp = b.readFloat(); in.signal = b.readBoolean();
            l.add(in);
        }
        return l;
    }
}

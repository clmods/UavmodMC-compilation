package com.example.uavwarfare.block;

import com.example.uavwarfare.item.ControllerItem;
import com.example.uavwarfare.item.UavItem;
import net.minecraft.block.*;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.StateManager;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/** Пусковая установка: хранит 1 дрон. Запуск ТОЛЬКО через пульт (кнопка в GUI). */
public class LauncherBlock extends BlockWithEntity {
    public static final net.minecraft.state.property.DirectionProperty FACING = HorizontalFacingBlock.FACING;
    private static final VoxelShape SHAPE = Block.createCuboidShape(0, 0, 0, 16, 6, 16);

    public LauncherBlock(Settings s) { super(s); setDefaultState(getStateManager().getDefaultState().with(FACING, net.minecraft.util.math.Direction.NORTH)); }
    @Override protected void appendProperties(StateManager.Builder<Block, BlockState> b) { b.add(FACING); }
    @Override public BlockState getPlacementState(ItemPlacementContext c) { return getDefaultState().with(FACING, c.getPlayerFacing()); }
    @Override public BlockEntity createBlockEntity(BlockView w) { return new LauncherBlockEntity(); }
    @Override public BlockRenderType getRenderType(BlockState s) { return BlockRenderType.MODEL; }
    @Override public VoxelShape getOutlineShape(BlockState s, BlockView w, BlockPos p, ShapeContext c) { return SHAPE; }

    @Override
    public ActionResult onUse(BlockState st, World w, BlockPos pos, PlayerEntity pl, Hand hand, BlockHitResult hit) {
        ItemStack held = pl.getStackInHand(hand);
        if (held.getItem() instanceof ControllerItem) return ActionResult.PASS;   // пульт обработает сам
        if (w.isClient) return ActionResult.SUCCESS;
        BlockEntity be = w.getBlockEntity(pos);
        if (!(be instanceof LauncherBlockEntity)) return ActionResult.PASS;
        LauncherBlockEntity l = (LauncherBlockEntity) be;
        if (held.getItem() instanceof UavItem) {
            if (l.insert(held)) { if (!pl.abilities.creativeMode) held.decrement(1); }
            else pl.sendMessage(new TranslatableText("msg.uavwarfare.launcher_busy"), true);
        } else if (held.isEmpty()) {
            ItemStack out = l.eject();
            if (!out.isEmpty()) pl.giveItemStack(out);
        }
        return ActionResult.CONSUME;
    }

    @Override
    public void onStateReplaced(BlockState s, World w, BlockPos pos, BlockState ns, boolean moved) {
        if (!s.isOf(ns.getBlock())) {
            BlockEntity be = w.getBlockEntity(pos);
            if (be instanceof LauncherBlockEntity) dropStack(w, pos, ((LauncherBlockEntity) be).eject());
        }
        super.onStateReplaced(s, w, pos, ns, moved);
    }
}

package com.example.uavwarfare.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Невидимое «кресло» стрелка: держит игрока на месте, мышь свободно вращает камеру. */
public class TurretSeatEntity extends Entity {
    private BlockPos turretPos;
    public TurretSeatEntity(EntityType<?> t, World w) { super(t, w); setNoGravity(true); }
    public BlockPos getTurretPos() { return turretPos; }
    public void setTurretPos(BlockPos p) { turretPos = p; }
    @Override protected void initDataTracker() {}
    @Override public void tick() {
        super.tick();
        if (!world.isClient && age > 5 && getPassengerList().isEmpty()) remove();
    }
    @Override public boolean isInvisible() { return true; }
    @Override protected void readCustomDataFromTag(CompoundTag t) { if (t.contains("Pos2")) turretPos = BlockPos.fromLong(t.getLong("Pos2")); }
    @Override protected void writeCustomDataToTag(CompoundTag t) { if (turretPos != null) t.putLong("Pos2", turretPos.asLong()); }
    @Override public Packet<?> createSpawnPacket() { return new EntitySpawnS2CPacket(this); }
}

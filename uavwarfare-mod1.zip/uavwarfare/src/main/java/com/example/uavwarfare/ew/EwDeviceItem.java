package com.example.uavwarfare.ew;

import com.example.uavwarfare.client.ClientHooks;
import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.entity.AbstractUavEntity;
import com.example.uavwarfare.registry.ModParticles;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;

/** Отдельный инструмент РЭБ. ПКМ — GUI (режим/цель), Shift+ПКМ — активация. Состояние в NBT: Mode, CooldownUntil, ActiveUntil. */
public class EwDeviceItem extends Item {
    public EwDeviceItem(Settings s) { super(s); }

    public static EwMode getMode(ItemStack s) { return s.hasTag() && s.getTag().getBoolean("Manual") ? EwMode.MANUAL : EwMode.AUTO; }
    public static void setMode(ItemStack s, EwMode m) { s.getOrCreateTag().putBoolean("Manual", m == EwMode.MANUAL); }
    public static long cooldownUntil(ItemStack s) { return s.hasTag() ? s.getTag().getLong("CooldownUntil") : 0L; }
    public static boolean ready(ItemStack s, long now) { return now >= cooldownUntil(s); }

    public static ItemStack find(PlayerEntity p) {
        if (p.getMainHandStack().getItem() instanceof EwDeviceItem) return p.getMainHandStack();
        if (p.getOffHandStack().getItem() instanceof EwDeviceItem) return p.getOffHandStack();
        return null;
    }

    @Override public TypedActionResult<ItemStack> use(World w, PlayerEntity p, Hand h) {
        ItemStack s = p.getStackInHand(h);
        if (p.isSneaking()) { if (!w.isClient) activate((ServerPlayerEntity) p, s); }
        else if (w.isClient) ClientHooks.openEwScreen();
        return TypedActionResult.success(s);
    }

    /** Shift+ПКМ. На кулдауне не включается. AUTO: окно «ewActiveTicks» с повторным сканом каждые 5 тиков. */
    private void activate(ServerPlayerEntity p, ItemStack s) {
        UavConfig c = UavConfig.get();
        long now = p.world.getTime();
        if (!ready(s, now)) { p.sendMessage(new TranslatableText("msg.uavwarfare.ew_cooldown", (cooldownUntil(s) - now) / 20 + 1), true); return; }
        if (getMode(s) == EwMode.MANUAL) { p.sendMessage(new TranslatableText("msg.uavwarfare.ew_manual_hint"), true); return; }
        CompoundTag t = s.getOrCreateTag();
        t.putLong("ActiveUntil", now + c.ewActiveTicks);
        t.putLong("CooldownUntil", now + c.ewCooldownTicks);
        p.world.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.PLAYERS, 1.5f, 1.8f);
        pulse(p, p.world);
    }

    /** Ручной режим: «Заглушить» выбранную цель в радиусе. */
    public static void manualJam(ServerPlayerEntity p, ItemStack s, AbstractUavEntity target) {
        UavConfig c = UavConfig.get();
        long now = p.world.getTime();
        if (getMode(s) != EwMode.MANUAL || !ready(s, now) || target.squaredDistanceTo(p) > c.ewRadius * c.ewRadius) return;
        if (EwJammer.jam(target)) {
            s.getOrCreateTag().putLong("CooldownUntil", now + c.ewCooldownTicks);
            p.world.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.PLAYERS, 1.5f, 1.8f);
        }
    }

    private static void pulse(PlayerEntity p, World w) {
        List<AbstractUavEntity> list = EwScanner.scan(w, p.getPos(), UavConfig.get().ewRadius);
        for (AbstractUavEntity u : list) EwJammer.jam(u);
        ServerWorld sw = (ServerWorld) w;
        double r = UavConfig.get().ewRadius * 0.5;
        for (int i = 0; i < 24; i++) {   // кольцо помех вокруг игрока
            double a = i * Math.PI / 12;
            sw.spawnParticles(ModParticles.JAM, p.getX() + Math.cos(a) * r, p.getY() + 1.0, p.getZ() + Math.sin(a) * r, 1, 0, 0.2, 0, 0.0);
        }
    }

    @Override public void inventoryTick(ItemStack s, World w, Entity e, int slot, boolean sel) {
        if (w.isClient || !(e instanceof PlayerEntity) || getMode(s) != EwMode.AUTO) return;
        if (w.getTime() < (s.hasTag() ? s.getTag().getLong("ActiveUntil") : 0L) && w.getTime() % 5 == 0) pulse((PlayerEntity) e, w);
    }
}

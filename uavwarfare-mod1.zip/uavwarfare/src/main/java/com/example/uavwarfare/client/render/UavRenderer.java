package com.example.uavwarfare.client.render;

import com.example.uavwarfare.UavWarfare;
import com.example.uavwarfare.entity.AbstractUavEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class UavRenderer<T extends AbstractUavEntity> extends EntityRenderer<T> {
    private final UavModel<T> model;
    private final Identifier tex;

    public UavRenderer(EntityRenderDispatcher d, UavModel<T> model, String texName) {
        super(d);
        this.model = model;
        this.tex = UavWarfare.id("textures/entity/" + texName + ".png");
        this.shadowRadius = 0f;
    }

    @Override public Identifier getTexture(T e) { return tex; }

    @Override public void render(T e, float yawIgnored, float td, MatrixStack m, net.minecraft.client.render.VertexConsumerProvider vcp, int light) {
        m.push();
        m.translate(0, e.getHeight() / 2f, 0);
        float yaw = MathHelper.lerp(td, e.prevYaw, e.yaw);
        float pitch = MathHelper.lerp(td, e.prevPitch, e.pitch);
        // Порядок: курс → тангаж (+ = нос вниз) → крен (+ = правое крыло вниз) → переворот осей модели (Y вниз, нос −Z).
        m.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(180f - yaw));
        m.multiply(Vector3f.POSITIVE_X.getDegreesQuaternion(-pitch));
        m.multiply(Vector3f.POSITIVE_Z.getDegreesQuaternion(-e.getRoll(td)));
        m.scale(-1f, -1f, 1f);
        model.setAngles(e, 0, 0, e.age + td, 0, 0);
        model.render(m, vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(tex)), light, OverlayTexture.DEFAULT_UV, 1f, 1f, 1f, 1f);
        m.pop();
        super.render(e, yawIgnored, td, m, vcp, light);
    }
}

package com.example.uavwarfare.client.screen;

import com.example.uavwarfare.config.UavConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.BlockState;
import net.minecraft.block.MaterialColor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.tag.FluidTags;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.ChunkStatus;

/**
 * Текстура карты 1000×1000 блоков (по умолчанию 4 блока/пиксель → 250×250).
 * Рельеф берётся из уже ЗАГРУЖЕННЫХ клиентом чанков (чанки не форсятся), остальное — тёмный «туман».
 */
@Environment(EnvType.CLIENT)
public final class ClientMapCache {
    public static int texPx, scale, originX, originZ;
    public static Identifier id;
    private static NativeImageBackedTexture tex;
    private static NativeImage img;
    private static int cursor;
    private static String dim = "";
    private ClientMapCache() {}

    public static void prepare(MinecraftClient mc, int px, int pz) {
        UavConfig c = UavConfig.get();
        scale = Math.max(1, c.mapBlocksPerPixel);
        texPx = c.mapSize / scale;
        int ox = Math.floorDiv(px - c.mapSize / 2, 64) * 64, oz = Math.floorDiv(pz - c.mapSize / 2, 64) * 64;
        String d = mc.world.getRegistryKey().getValue().toString();
        if (tex != null && ox == originX && oz == originZ && d.equals(dim)) return;
        if (id != null) mc.getTextureManager().destroyTexture(id);
        originX = ox; originZ = oz; dim = d; cursor = 0;
        img = new NativeImage(texPx, texPx, true);
        for (int y = 0; y < texPx; y++) for (int x = 0; x < texPx; x++) img.setPixelColor(x, y, 0xFF1A1410);
        tex = new NativeImageBackedTexture(img);
        id = mc.getTextureManager().registerDynamicTexture("uavwarfare_map", tex);
        tex.upload();
    }

    /** Сканируем budget пикселей за тик по кругу (дозагрузка по мере прогрузки чанков). */
    public static void scan(ClientWorld w, int budget) {
        if (tex == null) return;
        boolean dirty = false;
        for (int n = 0; n < budget; n++) {
            int i = cursor % texPx, j = cursor / texPx;
            cursor = (cursor + 1) % (texPx * texPx);
            int bx = originX + i * scale + scale / 2, bz = originZ + j * scale + scale / 2;
            if (w.getChunkManager().getChunk(bx >> 4, bz >> 4, ChunkStatus.FULL, false) == null) continue;
            int top = w.getTopY(Heightmap.Type.WORLD_SURFACE, bx, bz);
            BlockPos p = new BlockPos(bx, top - 1, bz);
            BlockState s = w.getBlockState(p);
            int col;
            if (s.getFluidState().isIn(FluidTags.WATER)) col = 0x2F5FC8;
            else {
                MaterialColor mc = s.getMaterialColor(w, p);
                col = mc == MaterialColor.CLEAR ? 0x303030 : mc.color;
            }
            float f = 0.6f + 0.4f * MathHelper.clamp((top - 50) / 60f, 0f, 1f);   // подсветка по высоте
            int r = (int) (((col >> 16) & 255) * f), g = (int) (((col >> 8) & 255) * f), b = (int) ((col & 255) * f);
            img.setPixelColor(i, j, 0xFF000000 | (b << 16) | (g << 8) | r);          // ABGR
            dirty = true;
        }
        if (dirty) tex.upload();
    }
}

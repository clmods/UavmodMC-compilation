package com.example.uavwarfare.item;

import com.example.uavwarfare.block.LauncherBlock;
import com.example.uavwarfare.network.UavNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class ControllerItem extends Item {
    public ControllerItem(Settings s) { super(s); }

    /** ПКМ в воздух — открыть тактическую карту. */
    @Override public TypedActionResult<ItemStack> use(World w, PlayerEntity p, Hand h) {
        ItemStack s = p.getStackInHand(h);
        if (!w.isClient) ServerPlayNetworking.send((ServerPlayerEntity) p, UavNetworking.CTRL_OPEN, UavNetworking.buildState((ServerPlayerEntity) p, s));
        return TypedActionResult.success(s);
    }

    /** Shift+ПКМ по установке — привязать/отвязать (макс. 5). */
    @Override public ActionResult useOnBlock(ItemUsageContext c) {
        PlayerEntity p = c.getPlayer();
        if (p == null || !p.isSneaking() || !(c.getWorld().getBlockState(c.getBlockPos()).getBlock() instanceof LauncherBlock)) return ActionResult.PASS;
        if (!c.getWorld().isClient) {
            int r = LauncherLinkManager.toggle(c.getStack(), c.getBlockPos(), c.getWorld().getRegistryKey().getValue().toString());
            p.sendMessage(new TranslatableText(r == 1 ? "msg.uavwarfare.linked" : r == 0 ? "msg.uavwarfare.unlinked" : "msg.uavwarfare.link_full"), true);
        }
        return ActionResult.SUCCESS;
    }
}

package com.example.uavwarfare.uav;

import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.entity.AbstractUavEntity;
import com.example.uavwarfare.item.ControllerItem;
import com.example.uavwarfare.item.LauncherLinkManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

/** Вспомогательная навигация: связь (60 блоков), рельеф, высота земли. Сам полёт — в AbstractUavEntity. */
public final class UavNavigation {
    private UavNavigation() {}

    /** Связь есть, если рядом (<= signalRange) игрок с пультом, привязанным к домашней пусковой установке дрона. */
    public static boolean hasSignal(AbstractUavEntity uav) {
        double r2 = UavConfig.get().signalRange * UavConfig.get().signalRange;
        BlockPos home = uav.getHome();
        if (home == null) return false;
        String dim = uav.world.getRegistryKey().getValue().toString();
        for (PlayerEntity p : uav.world.getPlayers()) {
            if (p.isSpectator() || p.squaredDistanceTo(uav) > r2) continue;
            if (playerHasLink(p, home, dim)) return true;
        }
        return false;
    }

    private static boolean playerHasLink(PlayerEntity p, BlockPos home, String dim) {
        for (ItemStack s : p.inventory.main) if (linked(s, home, dim)) return true;
        for (ItemStack s : p.inventory.offHand) if (linked(s, home, dim)) return true;
        return false;
    }

    private static boolean linked(ItemStack s, BlockPos home, String dim) {
        return s.getItem() instanceof ControllerItem && LauncherLinkManager.has(s, home, dim);
    }

    /** Высота поверхности (только в загруженных чанках — чтобы не форсить генерацию). */
    public static double groundAt(World w, double x, double z, double fallback) {
        BlockPos bp = new BlockPos(x, 64, z);
        if (!w.isChunkLoaded(bp)) return fallback;
        return w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, MathHelper.floor(x), MathHelper.floor(z));
    }

    /** «Пол» маршрута: максимум рельефа впереди по курсу (+14 блоков запаса). */
    public static double terrainFloor(AbstractUavEntity u) {
        Vec3d d = Vec3d.fromPolar(0, u.yaw);
        double f = -64;
        int[] steps = {0, 16, 32, 56};
        for (int s : steps) {
            double x = u.getX() + d.x * s, z = u.getZ() + d.z * s;
            double g = groundAt(u.world, x, z, -999);
            if (g > -999) f = Math.max(f, g + 14);
        }
        return f;
    }
}

package com.example.uavwarfare.registry;

import com.example.uavwarfare.UavWarfare;
import com.example.uavwarfare.ew.EwDeviceItem;
import com.example.uavwarfare.item.ControllerItem;
import com.example.uavwarfare.item.UavItem;
import com.example.uavwarfare.uav.UavType;
import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.minecraft.item.*;
import net.minecraft.util.registry.Registry;

public class ModItems {
    public static ItemGroup GROUP;
    public static Item CONTROLLER, EW_KIT, AFL196, SHAHED136, TRACER_AMMO, LAUNCHER, TURRET;

    private static Item reg(String n, Item i) { return Registry.register(Registry.ITEM, UavWarfare.id(n), i); }

    public static void register() {
        GROUP = FabricItemGroupBuilder.build(UavWarfare.id("main"), () -> new ItemStack(CONTROLLER));
        CONTROLLER = reg("controller", new ControllerItem(new Item.Settings().group(GROUP).maxCount(1)));
        EW_KIT = reg("ew_kit", new EwDeviceItem(new Item.Settings().group(GROUP).maxCount(1)));
        AFL196 = reg("afl196", new UavItem(UavType.AFL196, new Item.Settings().group(GROUP).maxCount(1)));
        SHAHED136 = reg("shahed136", new UavItem(UavType.SHAHED136, new Item.Settings().group(GROUP).maxCount(1)));
        TRACER_AMMO = reg("tracer_ammo", new Item(new Item.Settings().group(GROUP)));
        LAUNCHER = reg("launcher", new BlockItem(ModBlocks.LAUNCHER, new Item.Settings().group(GROUP)));
        TURRET = reg("gun_turret", new BlockItem(ModBlocks.TURRET, new Item.Settings().group(GROUP)));
    }
}

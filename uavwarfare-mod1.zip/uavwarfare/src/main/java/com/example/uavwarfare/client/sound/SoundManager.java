package com.example.uavwarfare.client.sound;

import com.example.uavwarfare.config.UavConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

/** Кривая громкости по расстоянию: smoothstep внутри каждой полосы (200–150, 150–100, 100–50, 50–0), не линейная. */
@Environment(EnvType.CLIENT)
public final class SoundManager {
    private SoundManager() {}

    /** smoothstep(t) = 3t² − 2t³: нулевая производная на краях полосы → нет «ступенек» на стыках. */
    public static float smoothstep(float t) { t = Math.max(0f, Math.min(1f, t)); return t * t * (3f - 2f * t); }

    public static float volumeAt(double d) {
        UavConfig c = UavConfig.get();
        double[] D = c.soundDist; float[] V = c.soundVol;
        if (d <= D[0]) return V[0];
        for (int i = 0; i < D.length - 1; i++) {
            if (d <= D[i + 1]) {
                float t = (float) ((d - D[i]) / (D[i + 1] - D[i]));
                return V[i] + (V[i + 1] - V[i]) * smoothstep(t);
            }
        }
        // Дальше 200 блоков — плавно к нулю на зоне soundFadeZone (без обрыва).
        double over = d - D[D.length - 1];
        if (over >= c.soundFadeZone) return 0f;
        return V[V.length - 1] * (1f - smoothstep((float) (over / c.soundFadeZone)));
    }

    /** Тон 0.95…1.05 по расстоянию (ближе — чуть выше). */
    public static float pitchAt(double d) {
        float t = (float) Math.min(1.0, d / UavConfig.get().soundMaxRadius);
        return 0.95f + 0.10f * (1f - smoothstep(t));
    }
}

package com.example.uavwarfare.item;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/** До 5 привязок пульта к пусковым установкам. Хранится в NBT предмета → переживает выход игрока. */
public final class LauncherLinkManager {
    public static final int MAX_LINKS = 5;
    private LauncherLinkManager() {}

    /** Список установок ТЕКУЩЕГО измерения (индекс = номер вкладки). */
    public static List<BlockPos> getLinks(ItemStack s, String dim) {
        List<BlockPos> out = new ArrayList<>();
        CompoundTag t = s.getTag();
        if (t == null) return out;
        ListTag l = t.getList("Links", 10);
        for (int i = 0; i < l.size(); i++) {
            CompoundTag c = l.getCompound(i);
            if (c.getString("Dim").equals(dim)) out.add(new BlockPos(c.getInt("X"), c.getInt("Y"), c.getInt("Z")));
        }
        return out;
    }

    public static boolean has(ItemStack s, BlockPos p, String dim) { return getLinks(s, dim).contains(p); }

    /** @return 1 — привязана, 0 — отвязана, -1 — лимит (5). */
    public static int toggle(ItemStack s, BlockPos p, String dim) {
        CompoundTag t = s.getOrCreateTag();
        ListTag l = t.getList("Links", 10);
        for (int i = 0; i < l.size(); i++) {
            CompoundTag c = l.getCompound(i);
            if (c.getString("Dim").equals(dim) && c.getInt("X") == p.getX() && c.getInt("Y") == p.getY() && c.getInt("Z") == p.getZ()) {
                l.remove(i); t.put("Links", l); return 0;
            }
        }
        if (l.size() >= MAX_LINKS) return -1;
        CompoundTag c = new CompoundTag();
        c.putString("Dim", dim); c.putInt("X", p.getX()); c.putInt("Y", p.getY()); c.putInt("Z", p.getZ());
        l.add(c); t.put("Links", l);
        return 1;
    }
}

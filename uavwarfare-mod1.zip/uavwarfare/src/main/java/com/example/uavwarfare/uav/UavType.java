package com.example.uavwarfare.uav;

import com.example.uavwarfare.entity.*;
import com.example.uavwarfare.registry.ModEntities;
import com.example.uavwarfare.registry.ModItems;
import net.minecraft.item.Item;
import net.minecraft.world.World;

public enum UavType {
    AFL196, SHAHED136;
    public Item item() { return this == AFL196 ? ModItems.AFL196 : ModItems.SHAHED136; }
    public AbstractUavEntity create(World w) {
        return this == AFL196 ? new Afl196Entity(ModEntities.AFL196, w) : new Shahed136Entity(ModEntities.SHAHED136, w);
    }
}

package com.example.uavwarfare.entity;

import com.example.uavwarfare.block.LauncherBlockEntity;
import com.example.uavwarfare.client.ClientHooks;
import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.uav.UavNavigation;
import com.example.uavwarfare.uav.UavDeathHandler;
import com.example.uavwarfare.uav.UavType;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.*;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ChunkTicketType;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.*;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.Comparator;

/**
 * Базовый БПЛА самолётного типа. Без владельца и без UUID-привязки.
 * Физика кинематическая: курс/тангаж/крен интегрируются вручную, подъёмная сила неявная (скорость вдоль носа).
 */
public abstract class AbstractUavEntity extends Entity {
    public enum DeathMode { NONE, AIR_EXPLODE, FALL_EXPLODE, JAM_DESCEND }

    private static final TrackedData<Integer> DEATH_MODE = DataTracker.registerData(AbstractUavEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Float> ROLL = DataTracker.registerData(AbstractUavEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Boolean> DIVING = DataTracker.registerData(AbstractUavEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    private static final ChunkTicketType<ChunkPos> TICKET =
            ChunkTicketType.create("uavwarfare_uav", Comparator.comparingLong(ChunkPos::toLong), 3);

    // --- серверное состояние ---
    protected Vec3d waypoint;        // null → кружим (loiter)
    protected BlockPos home;
    protected double cruiseY = 100;
    protected boolean rth;
    protected float speed;
    protected float damageTaken;
    protected int noSignal;
    protected double terrainFloor = -64;
    protected float roll;
    protected float fallSpin;
    private boolean exploding;

    // --- клиентское состояние ---
    public float prevRoll;
    public int deathTicks;
    private int lerpSteps;
    private double lerpX, lerpY, lerpZ;
    private float lerpYaw, lerpPitch;
    private float groundDist = 64f;
    private boolean soundStarted;

    protected AbstractUavEntity(EntityType<?> type, World world) {
        super(type, world);
        setSilent(true);
    }

    // ---------- параметры типа ----------
    public abstract UavType type();
    public abstract float maxHealth();
    public abstract float maxSpeed();
    public abstract float maxYawRate();      // град/тик
    public abstract float propSpin();        // град/тик (визуально)
    public abstract SoundEvent engineSound();
    public float minSpeed() { return maxSpeed() * 0.55f; }
    public float soundPitchWobble() { return 0f; }

    // ---------- tracker ----------
    @Override protected void initDataTracker() {
        dataTracker.startTracking(DEATH_MODE, 0);
        dataTracker.startTracking(ROLL, 0f);
        dataTracker.startTracking(DIVING, false);
    }
    public DeathMode getDeathMode() { return DeathMode.values()[MathHelper.clamp(dataTracker.get(DEATH_MODE), 0, 3)]; }
    public boolean isDiving() { return dataTracker.get(DIVING); }
    public float getRoll(float td) { return MathHelper.lerp(td, prevRoll, roll); }
    public BlockPos getHome() { return home; }
    public Vec3d getWaypoint() { return waypoint; }
    public float getHealthFraction() { return MathHelper.clamp(1f - damageTaken / maxHealth(), 0f, 1f); }
    public boolean isExploding() { return exploding; }
    public boolean markExploding() { boolean was = exploding; exploding = true; return was; }

    /** Смена режима гибели. AIR_EXPLODE обрабатывает UavDeathHandler (мгновенный взрыв). */
    public void applyDeathMode(DeathMode m) {
        dataTracker.set(DEATH_MODE, m.ordinal());
        waypoint = null; rth = false;
        dataTracker.set(DIVING, false);
        fallSpin = 0;
    }

    // ---------- команды пульта ----------
    public void launch(BlockPos home, double cruiseY) {
        this.home = home; this.cruiseY = cruiseY;
        this.speed = maxSpeed() * 0.6f;
        this.pitch = -12f;
        setVelocity(Vec3d.fromPolar(pitch, yaw).multiply(speed));
    }
    public void setWaypoint(double x, double z) { waypoint = new Vec3d(x, 0, z); rth = false; noSignal = 0; }
    public void commandRth() { rth = true; waypoint = null; }
    public void addDamage(float d) { damageTaken += d; }
    public float getDamageTaken() { return damageTaken; }

    /** Скрытый статус в домашней пусковой установке (для вкладок пульта). */
    public void reportHome(int status) {
        if (home != null && !world.isClient && world.isChunkLoaded(home)) {
            BlockEntity be = world.getBlockEntity(home);
            if (be instanceof LauncherBlockEntity) ((LauncherBlockEntity) be).markStatus(this, status);
        }
    }

    // ---------- тик ----------
    @Override public void tick() {
        super.tick();
        if (world.isClient) clientTick(); else serverTick();
    }

    private void serverTick() {
        ServerWorld sw = (ServerWorld) world;
        if (UavConfig.get().chunkLoading) {
            ChunkPos cp = new ChunkPos(getBlockPos());
            sw.getChunkManager().addTicket(TICKET, cp, 2, cp);
        }
        switch (getDeathMode()) {
            case NONE: navigate(); break;
            case FALL_EXPLODE: fallTick(); break;
            case JAM_DESCEND: jamTick(); break;
            default: break;
        }
        if (!isAlive()) return;
        if (age > 20) {
            if (isTouchingWater()) UavDeathHandler.waterImpact(this);
            else if (horizontalCollision || verticalCollision || onGround) UavDeathHandler.impact(this);
        }
    }

    private void applyMotion(Vec3d v) {
        setVelocity(v);
        move(MovementType.SELF, v);
    }

    private void setRoll(float r) {
        roll = r;
        if (Math.abs(r - dataTracker.get(ROLL)) > 0.3f) dataTracker.set(ROLL, r);
    }

    /** Нормальный полёт: loiter / путевая точка / RTH. */
    private void navigate() {
        UavConfig c = UavConfig.get();

        // --- связь: актуальна только пока нет задания (с точкой дрон автономен) ---
        if (waypoint == null && !rth && age % 10 == 0) {
            if (UavNavigation.hasSignal(this)) noSignal = 0; else noSignal += 10;
            if (noSignal >= c.signalLossGraceTicks) {
                if (c.rthOnSignalLoss) rth = true;
                else { UavDeathHandler.startFall(this); return; }
            }
        }

        Vec3d pos = getPos();
        Vec3d target = null;
        boolean toHome = false;
        if (rth && home != null) { target = Vec3d.ofCenter(home); toHome = true; }
        else if (waypoint != null) target = waypoint;

        double hd = 0;
        float yawStep;
        if (target == null) {
            yawStep = maxYawRate() * 0.45f;   // кружим: постоянная угловая скорость → замкнутая окружность
        } else {
            double dx = target.x - pos.x, dz = target.z - pos.z;
            hd = Math.sqrt(dx * dx + dz * dz);
            // В Minecraft yaw = atan2(-dx, dz). Ограничиваем скорость поворота (радиус разворота ≈ v/ω).
            float want = (float) (MathHelper.atan2(-dx, dz) * 57.29578);
            yawStep = MathHelper.clamp(MathHelper.wrapDegrees(want - yaw), -maxYawRate(), maxYawRate());
            if (hd < c.arriveRadius && !toHome) yawStep = 0;   // над целью курс не меняем
        }

        if (age % 5 == 0) terrainFloor = UavNavigation.terrainFloor(this);
        double goalY = Math.max(cruiseY, terrainFloor);
        boolean terminal = false;
        if (target != null) {
            double gy = toHome ? home.getY() + 1.5 : UavNavigation.groundAt(world, target.x, target.z, home != null ? home.getY() : pos.y - 30);
            // Планирование начинается за ~3.5×перепад высот (уклон ≈ 16°) — плавный спуск «параболой».
            double glide = Math.max(30.0, (pos.y - gy) * 3.5);
            if (hd < glide) { goalY = gy; terminal = true; }
            if (toHome && hd < 6 && pos.y - home.getY() < 6) { dock(); return; }
        }
        double dy = goalY - pos.y;
        float pitchGoal;
        if (terminal) {
            pitchGoal = MathHelper.clamp((float) Math.toDegrees(Math.atan2(-dy, Math.max(hd, 1.0))), -20f, toHome ? 25f : 60f);
            if (!toHome && hd < c.arriveRadius) pitchGoal = Math.max(pitchGoal, 40f);   // прибытие: пологое пикирование
        } else {
            pitchGoal = MathHelper.clamp((float) (-dy * 1.2), -20f, 14f);              // «-» = нос вверх
        }
        pitch += MathHelper.clamp((pitchGoal - pitch) * 0.15f, -1.5f, 1.5f);

        float wantSpeed = maxSpeed();
        if (toHome && hd < 40) wantSpeed = Math.max(minSpeed(), maxSpeed() * (float) (hd / 40.0));
        speed += (wantSpeed - speed) * 0.05f;

        // Крен пропорционален угловой скорости поворота (координированный вираж).
        setRoll(roll + (MathHelper.clamp(yawStep * 10f, -45f, 45f) - roll) * 0.12f);
        yaw = MathHelper.wrapDegrees(yaw + yawStep);
        if (terminal != isDiving()) dataTracker.set(DIVING, terminal && !toHome);

        applyMotion(Vec3d.fromPolar(pitch, yaw).multiply(speed));
    }

    /** Сценарий A2: потеря управления — вращение нарастает, нос вниз, баллистика, дым. */
    private void fallTick() {
        fallSpin = Math.min(fallSpin + 1.2f, 38f);
        yaw = MathHelper.wrapDegrees(yaw + fallSpin);
        setRoll(roll + fallSpin * 1.6f);
        pitch += (65f - pitch) * 0.04f;
        Vec3d v = getVelocity();
        applyMotion(new Vec3d(v.x * 0.985, Math.max(v.y - 0.045, -1.7), v.z * 0.985));
        ServerWorld sw = (ServerWorld) world;
        sw.spawnParticles(ParticleTypes.LARGE_SMOKE, getX(), getY(), getZ(), 2, 0.2, 0.1, 0.2, 0.01);
        if (age % 3 == 0) sw.spawnParticles(ParticleTypes.FLAME, getX(), getY(), getZ(), 1, 0.15, 0.05, 0.15, 0.01);
    }

    /** Сценарий B (РЭБ): управляемый спуск без кувырков, скорость падает, сразу ни взрыва, ни хаоса. */
    private void jamTick() {
        speed += (minSpeed() - speed) * 0.01f;
        pitch += (14f - pitch) * 0.03f;
        setRoll(roll * 0.95f);
        Vec3d d = Vec3d.fromPolar(pitch, yaw);
        applyMotion(new Vec3d(d.x * speed, d.y * speed - 0.075, d.z * speed));   // 0.075 — «просадка» без тяги
        if (age % 4 == 0) ((ServerWorld) world).spawnParticles(ParticleTypes.CRIT, getX(), getY(), getZ(), 2, 0.3, 0.1, 0.3, 0.05);
    }

    /** Возврат на пусковую: дрон «стыкуется» и снова становится предметом в установке. */
    private void dock() {
        if (home != null && world.isChunkLoaded(home)) {
            BlockEntity be = world.getBlockEntity(home);
            if (be instanceof LauncherBlockEntity && ((LauncherBlockEntity) be).dock(this)) { remove(); return; }
        }
        dropStack(new ItemStack(type().item()));
        remove();
    }

    // ---------- клиент ----------
    private void clientTick() {
        if (!soundStarted) { soundStarted = true; ClientHooks.startEngineSound(this); }
        prevRoll = roll;
        roll += (dataTracker.get(ROLL) - roll) * 0.4f;
        if (lerpSteps > 0) {
            double k = 1.0 / lerpSteps;
            setPosition(getX() + (lerpX - getX()) * k, getY() + (lerpY - getY()) * k, getZ() + (lerpZ - getZ()) * k);
            yaw += MathHelper.wrapDegrees(lerpYaw - yaw) * (float) k;
            pitch += (lerpPitch - pitch) * (float) k;
            lerpSteps--;
        }
        DeathMode dm = getDeathMode();
        if (dm != DeathMode.NONE) deathTicks++;
        if ((dm != DeathMode.NONE || isDiving())) { if (age % 2 == 0) groundDist = computeGroundDist(); } else groundDist = 64f;
        if (dm == DeathMode.FALL_EXPLODE) {
            world.addParticle(ParticleTypes.LARGE_SMOKE, getX(), getY(), getZ(), 0, 0.02, 0);
            if (age % 2 == 0) world.addParticle(ParticleTypes.FLAME, getX(), getY(), getZ(), 0, 0, 0);
        }
    }

    private float computeGroundDist() {
        Vec3d p = getPos();
        net.minecraft.util.hit.BlockHitResult r = world.raycast(new RaycastContext(p, p.add(0, -64, 0),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, this));
        return r.getType() == net.minecraft.util.hit.HitResult.Type.MISS ? 64f : (float) (p.y - r.getPos().y);
    }

    /**
     * Множитель громкости двигателя (клиент). Плавность даёт lerp в UavEngineSoundInstance.
     * FALL: двигатель глохнет за ~1.5 с. JAM: «тарахтит» — то глохнет, то оживает. Перед землёй — затухание по высоте.
     */
    public float engineGain() {
        DeathMode dm = getDeathMode();
        float g = 1f;
        if (dm == DeathMode.FALL_EXPLODE) {
            g = MathHelper.clamp(1f - deathTicks / 30f, 0f, 1f);
        } else if (dm == DeathMode.JAM_DESCEND) {
            double t = (age + getEntityId() * 17) * 0.11;
            float v = (float) (Math.sin(t * 2.3) + 0.8 * Math.sin(t * 5.9 + 1.3));
            g = MathHelper.clamp((v + 0.35f) * 3f, 0f, 1f);          // порог: ниже — «заглох», выше — «завёлся»
            g *= 1f - 0.4f * MathHelper.clamp(deathTicks / 200f, 0f, 1f);
        }
        if (dm != DeathMode.NONE || isDiving()) g *= MathHelper.clamp((groundDist - 3f) / 14f, 0f, 1f);
        return g;
    }

    @Override
    public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int steps, boolean interpolate) {
        lerpX = x; lerpY = y; lerpZ = z; lerpYaw = yaw; lerpPitch = pitch; lerpSteps = 2;
    }

    @Override public boolean shouldRender(double distance) { return distance < 400.0 * 400.0; }

    // ---------- взаимодействие ----------
    @Override public boolean collides() { return true; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean isFireImmune() { return true; }
    @Override public boolean damage(DamageSource source, float amount) {
        if (source == DamageSource.OUT_OF_WORLD && !world.isClient) { remove(); return true; }
        return false;   // урон только через onTurretHit (сценарий A)
    }
    public void onTurretHit(float dmg, Vec3d at) { UavDeathHandler.onTurretHit(this, dmg, at); }

    // ---------- NBT / сеть ----------
    @Override protected void readCustomDataFromTag(CompoundTag t) {
        if (t.contains("WpX")) waypoint = new Vec3d(t.getDouble("WpX"), 0, t.getDouble("WpZ"));
        home = t.contains("Home") ? BlockPos.fromLong(t.getLong("Home")) : null;
        cruiseY = t.getDouble("CruiseY"); rth = t.getBoolean("Rth"); speed = t.getFloat("Speed");
        damageTaken = t.getFloat("Damage");
        dataTracker.set(DEATH_MODE, MathHelper.clamp(t.getInt("Death"), 0, 3));
    }
    @Override protected void writeCustomDataToTag(CompoundTag t) {
        if (waypoint != null) { t.putDouble("WpX", waypoint.x); t.putDouble("WpZ", waypoint.z); }
        if (home != null) t.putLong("Home", home.asLong());
        t.putDouble("CruiseY", cruiseY); t.putBoolean("Rth", rth); t.putFloat("Speed", speed);
        t.putFloat("Damage", damageTaken); t.putInt("Death", dataTracker.get(DEATH_MODE));
    }
    @Override public Packet<?> createSpawnPacket() { return new EntitySpawnS2CPacket(this); }
}

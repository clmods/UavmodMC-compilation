package com.example.uavwarfare.block;

import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.entity.AbstractUavEntity;
import com.example.uavwarfare.item.UavItem;
import com.example.uavwarfare.registry.ModBlockEntities;
import com.example.uavwarfare.uav.UavType;
import net.fabricmc.fabric.api.block.entity.BlockEntityClientSerializable;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Direction;

import java.util.UUID;

public class LauncherBlockEntity extends BlockEntity implements BlockEntityClientSerializable {
    /** Статусы для вкладок пульта. */
    public static final int ST_GROUND = 0, ST_FLIGHT = 1, ST_DOWN = 2, ST_EMPTY = 3, ST_OFFLINE = 4;

    private ItemStack drone = ItemStack.EMPTY;
    private UUID droneUuid;
    private int flightStatus = ST_EMPTY;   // ST_FLIGHT / ST_DOWN / ST_EMPTY, когда в установке пусто
    private int lastType;                  // ordinal UavType — чтобы вкладка помнила тип сбитого дрона

    public LauncherBlockEntity() { super(ModBlockEntities.LAUNCHER); }

    public ItemStack getDrone() { return drone; }
    public UUID getDroneUuid() { return droneUuid; }
    public int status() { return drone.isEmpty() ? flightStatus : ST_GROUND; }
    public int typeId() {   // 0 = нет, 1 = AFL, 2 = Shahed
        if (!drone.isEmpty() && drone.getItem() instanceof UavItem) return ((UavItem) drone.getItem()).type.ordinal() + 1;
        return flightStatus == ST_EMPTY ? 0 : lastType + 1;
    }

    public boolean insert(ItemStack s) {
        if (!drone.isEmpty() || flightStatus == ST_FLIGHT || !(s.getItem() instanceof UavItem)) return false;
        drone = new ItemStack(s.getItem());
        flightStatus = ST_EMPTY; droneUuid = null; changed();
        return true;
    }

    public ItemStack eject() {
        ItemStack out = drone;
        drone = ItemStack.EMPTY;
        if (flightStatus == ST_DOWN) flightStatus = ST_EMPTY;   // игрок «подтвердил» потерю
        changed();
        return out;
    }

    /** Запуск (вызывается из пакета пульта). */
    public boolean launch(ServerWorld w) {
        if (drone.isEmpty() || !(drone.getItem() instanceof UavItem)) return false;
        UavType t = ((UavItem) drone.getItem()).type;
        AbstractUavEntity e = t.create(w);
        Direction f = getCachedState().get(LauncherBlock.FACING);
        e.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY() + 0.8, pos.getZ() + 0.5, f.asRotation(), -12f);
        e.launch(pos, pos.getY() + UavConfig.get().cruiseHeight);
        if (!w.spawnEntity(e)) return false;
        droneUuid = e.getUuid(); lastType = t.ordinal();
        drone = ItemStack.EMPTY; flightStatus = ST_FLIGHT;
        changed();
        return true;
    }

    /** Дрон вернулся (RTH). */
    public boolean dock(AbstractUavEntity e) {
        if (!drone.isEmpty()) return false;
        drone = new ItemStack(e.type().item());
        droneUuid = null; flightStatus = ST_EMPTY; changed();
        return true;
    }

    /** Сообщение от дрона о потере (сбит / РЭБ / взорван). */
    public void markStatus(AbstractUavEntity e, int status) {
        if (e.getUuid().equals(droneUuid) && flightStatus == ST_FLIGHT) { flightStatus = status; changed(); }
    }

    private void changed() { markDirty(); if (world != null && !world.isClient) sync(); }

    @Override public CompoundTag toTag(CompoundTag t) {
        super.toTag(t);
        if (!drone.isEmpty()) t.put("Drone", drone.toTag(new CompoundTag()));
        if (droneUuid != null) t.putUuid("Uuid", droneUuid);
        t.putInt("St", flightStatus); t.putInt("Last", lastType);
        return t;
    }
    @Override public void fromTag(BlockState s, CompoundTag t) {
        super.fromTag(s, t);
        drone = t.contains("Drone") ? ItemStack.fromTag(t.getCompound("Drone")) : ItemStack.EMPTY;
        droneUuid = t.containsUuid("Uuid") ? t.getUuid("Uuid") : null;
        flightStatus = t.getInt("St"); lastType = t.getInt("Last");
    }
    @Override public void fromClientTag(CompoundTag t) { fromTag(getCachedState(), t); }
    @Override public CompoundTag toClientTag(CompoundTag t) { return toTag(t); }
}

package com.example.uavwarfare.client.screen;

import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.network.UavNetworking;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Тактическая карта: масштаб (колесо), панорама (ПКМ/СКМ-перетаскивание), ЛКМ — путевая точка, вкладки дронов (до 5). */
@Environment(EnvType.CLIENT)
public class ControllerScreen extends Screen {
    public static class Info {
        public BlockPos pos; public int status, type; public Vec3d drone = Vec3d.ZERO;
        public boolean hasWp, signal; public double wx, wz; public float hp;
    }
    private static final int[] STATUS_COLOR = {0xFFB0B0B0, 0xFF55FF55, 0xFFFF5555, 0xFF808080, 0xFF808080};
    private List<Info> infos = new ArrayList<>();
    private int selected = 0;
    private float zoom = 1f, cx, cz;
    private boolean centered;
    private int mapX, mapY, mapPx, viewU, viewV, region = 1;
    private String notice = ""; private int noticeTicks;

    public ControllerScreen(List<Info> infos) { super(new TranslatableText("screen.uavwarfare.controller")); this.infos = infos; }
    public void setInfos(List<Info> l) { infos = l; if (selected >= l.size()) selected = Math.max(0, l.size() - 1); }
    @Override public boolean isPauseScreen() { return false; }

    @Override protected void init() {
        mapPx = Math.min(height - 24, width - 150);
        mapX = width - mapPx - 10; mapY = (height - mapPx) / 2;
        ClientMapCache.prepare(client, (int) client.player.getX(), (int) client.player.getZ());
        if (!centered) {
            cx = (float) ((client.player.getX() - ClientMapCache.originX) / ClientMapCache.scale);
            cz = (float) ((client.player.getZ() - ClientMapCache.originZ) / ClientMapCache.scale);
            centered = true;
        }
        int by = 20 + 5 * 28 + 6;
        addButton(new ButtonWidget(8, by, 116, 20, new TranslatableText("gui.uavwarfare.launch"), b -> sendIdx(UavNetworking.CTRL_LAUNCH)));
        addButton(new ButtonWidget(8, by + 24, 116, 20, new TranslatableText("gui.uavwarfare.rth"), b -> sendIdx(UavNetworking.CTRL_RTH)));
        addButton(new ButtonWidget(8, by + 48, 56, 20, new TranslatableText("gui.uavwarfare.zoom_in"), b -> zoom = Math.min(8f, zoom * 1.5f)));
        addButton(new ButtonWidget(68, by + 48, 56, 20, new TranslatableText("gui.uavwarfare.zoom_out"), b -> zoom = Math.max(1f, zoom / 1.5f)));
    }

    private void sendIdx(net.minecraft.util.Identifier id) {
        if (infos.isEmpty()) return;
        PacketByteBuf b = PacketByteBufs.create(); b.writeInt(selected);
        ClientPlayNetworking.send(id, b);
    }

    @Override public void tick() {
        ClientMapCache.scan(client.world, 4000);
        if (noticeTicks > 0) noticeTicks--;
        if (client.player.age % 10 == 0) ClientPlayNetworking.send(UavNetworking.CTRL_REQUEST, PacketByteBufs.create());
    }

    private void notice(String key) { notice = new TranslatableText(key).getString(); noticeTicks = 60; }

    // мир → экран (null, если вне карты)
    private int[] toScreen(double wx, double wz) {
        float px = (float) ((wx - ClientMapCache.originX) / ClientMapCache.scale), pz = (float) ((wz - ClientMapCache.originZ) / ClientMapCache.scale);
        float sx = mapX + (px - viewU) * mapPx / region, sy = mapY + (pz - viewV) * mapPx / region;
        if (sx < mapX || sy < mapY || sx > mapX + mapPx || sy > mapY + mapPx) return null;
        return new int[]{(int) sx, (int) sy};
    }

    @Override public void render(MatrixStack ms, int mx, int my, float td) {
        renderBackground(ms);
        int tp = ClientMapCache.texPx;
        region = Math.max(16, Math.round(tp / zoom));
        float half = region / 2f;
        cx = MathHelper.clamp(cx, half, tp - half); cz = MathHelper.clamp(cz, half, tp - half);
        viewU = Math.round(cx - half); viewV = Math.round(cz - half);
        fill(ms, mapX - 2, mapY - 2, mapX + mapPx + 2, mapY + mapPx + 2, 0xFF303A44);
        RenderSystem.color4f(1f, 1f, 1f, 1f);
        client.getTextureManager().bindTexture(ClientMapCache.id);
        drawTexture(ms, mapX, mapY, mapPx, mapPx, (float) viewU, (float) viewV, region, region, tp, tp);

        // игрок
        int[] pp = toScreen(client.player.getX(), client.player.getZ());
        if (pp != null) fill(ms, pp[0] - 2, pp[1] - 2, pp[0] + 3, pp[1] + 3, 0xFFFFFFFF);
        // установки, дроны, точки
        for (int i = 0; i < infos.size(); i++) {
            Info in = infos.get(i);
            int[] l = toScreen(in.pos.getX() + 0.5, in.pos.getZ() + 0.5);
            if (l != null) { fill(ms, l[0] - 3, l[1] - 3, l[0] + 4, l[1] + 4, 0xFFFFD040); textRenderer.drawWithShadow(ms, String.valueOf(i + 1), l[0] + 5, l[1] - 4, 0xFFFFD040); }
            if (in.status == 1) {
                int[] d = toScreen(in.drone.x, in.drone.z);
                int col = i == selected ? 0xFF55FF55 : 0xFFFF9030;
                if (d != null) { fill(ms, d[0] - 2, d[1] - 2, d[0] + 3, d[1] + 3, col); textRenderer.drawWithShadow(ms, in.type == 1 ? "AH-196" : "SH-136", d[0] + 5, d[1] - 4, col); }
                if (in.hasWp) {
                    int[] w = toScreen(in.wx, in.wz);
                    if (w != null) {
                        fill(ms, w[0] - 3, w[1] - 3, w[0] + 4, w[1] + 4, 0xFF40E0FF);
                        if (d != null) for (int k = 1; k < 20; k++)   // пунктир дрон → точка
                            fill(ms, d[0] + (w[0] - d[0]) * k / 20, d[1] + (w[1] - d[1]) * k / 20, d[0] + (w[0] - d[0]) * k / 20 + 1, d[1] + (w[1] - d[1]) * k / 20 + 1, 0xAA40E0FF);
                    }
                }
            }
        }
        // вкладки
        drawCenteredText(ms, textRenderer, title, 66, 6, 0xFFFFFF);
        for (int i = 0; i < 5; i++) {
            int y = 20 + i * 28;
            boolean has = i < infos.size();
            fill(ms, 8, y, 124, y + 24, i == selected && has ? 0xFF3A5A3A : 0xFF202830);
            if (!has) { textRenderer.drawWithShadow(ms, (i + 1) + "  —", 12, y + 8, 0xFF606060); continue; }
            Info in = infos.get(i);
            String name = in.type == 1 ? "AH-196" : in.type == 2 ? "Shahed-136" : "---";
            textRenderer.drawWithShadow(ms, (i + 1) + "  " + name, 12, y + 3, 0xFFFFFFFF);
            String st = new TranslatableText("gui.uavwarfare.status." + in.status).getString()
                    + (in.status == 1 ? (in.signal ? "  " : "  ✖") + (int) (in.hp * 100) + "%" : "");
            textRenderer.drawWithShadow(ms, st, 12, y + 13, STATUS_COLOR[Math.min(in.status, 4)]);
        }
        textRenderer.drawWithShadow(ms, "x" + String.format("%.1f", zoom), mapX + 4, mapY + 4, 0xFFFFFFFF);
        if (noticeTicks > 0) drawCenteredText(ms, textRenderer, new net.minecraft.text.LiteralText(notice), mapX + mapPx / 2, mapY + mapPx - 14, 0xFFFF5555);
        super.render(ms, mx, my, td);
    }

    private boolean inMap(double mx, double my) { return mx >= mapX && my >= mapY && mx < mapX + mapPx && my < mapY + mapPx; }

    @Override public boolean mouseClicked(double mx, double my, int btn) {
        if (super.mouseClicked(mx, my, btn)) return true;
        if (btn != 0) return false;
        for (int i = 0; i < Math.min(5, infos.size()); i++) {
            int y = 20 + i * 28;
            if (mx >= 8 && mx < 124 && my >= y && my < y + 24) { selected = i; return true; }
        }
        if (inMap(mx, my)) {
            UavConfig c = UavConfig.get();
            double bx = ClientMapCache.originX + (viewU + (mx - mapX) * region / mapPx) * ClientMapCache.scale;
            double bz = ClientMapCache.originZ + (viewV + (my - mapY) * region / mapPx) * ClientMapCache.scale;
            if (infos.isEmpty() || infos.get(selected).status != 1) { notice("msg.uavwarfare.not_in_flight"); return true; }
            if (Math.hypot(bx - client.player.getX(), bz - client.player.getZ()) > c.maxFlightRange) { notice("msg.uavwarfare.out_of_range"); return true; }
            PacketByteBuf b = PacketByteBufs.create();
            b.writeInt(selected); b.writeInt(ClientMapCache.originX); b.writeInt(ClientMapCache.originZ); b.writeDouble(bx); b.writeDouble(bz);
            ClientPlayNetworking.send(UavNetworking.CTRL_WAYPOINT, b);
            return true;
        }
        return false;
    }

    @Override public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if ((btn == 1 || btn == 2) && inMap(mx, my)) { cx -= dx * region / mapPx; cz -= dy * region / mapPx; return true; }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override public boolean mouseScrolled(double mx, double my, double amount) {
        if (inMap(mx, my)) { zoom = MathHelper.clamp(zoom * (amount > 0 ? 1.25f : 0.8f), 1f, 8f); return true; }
        return super.mouseScrolled(mx, my, amount);
    }
}

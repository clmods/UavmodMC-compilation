package com.example.uavwarfare.client.render;

import com.example.uavwarfare.UavWarfare;
import com.example.uavwarfare.block.LauncherBlock;
import com.example.uavwarfare.block.LauncherBlockEntity;
import com.example.uavwarfare.item.UavItem;
import com.example.uavwarfare.uav.UavType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector3f;
import net.minecraft.util.Identifier;

/** Рисует дрон, лежащий на рельсе пусковой установки (мини-версия модели). */
@Environment(EnvType.CLIENT)
public class LauncherRenderer extends BlockEntityRenderer<LauncherBlockEntity> {
    private final Afl196Model afl = new Afl196Model();
    private final Shahed136Model shahed = new Shahed136Model();
    private static final Identifier T_AFL = UavWarfare.id("textures/entity/afl196.png"), T_SHA = UavWarfare.id("textures/entity/shahed136.png");

    public LauncherRenderer(BlockEntityRenderDispatcher d) { super(d); }

    @Override public void render(LauncherBlockEntity be, float td, MatrixStack m, VertexConsumerProvider vcp, int light, int overlay) {
        if (be.getDrone().isEmpty() || !(be.getDrone().getItem() instanceof UavItem)) return;
        UavType t = ((UavItem) be.getDrone().getItem()).type;
        float yaw = be.getCachedState().get(LauncherBlock.FACING).asRotation();
        m.push();
        m.translate(0.5, 0.55, 0.5);
        m.multiply(Vector3f.POSITIVE_Y.getDegreesQuaternion(180f - yaw));
        m.scale(-0.55f, -0.55f, 0.55f);
        net.minecraft.client.render.VertexConsumer vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(t == UavType.AFL196 ? T_AFL : T_SHA));
        if (t == UavType.AFL196) afl.render(m, vc, light, overlay, 1f, 1f, 1f, 1f); else shahed.render(m, vc, light, overlay, 1f, 1f, 1f, 1f);
        m.pop();
    }
}

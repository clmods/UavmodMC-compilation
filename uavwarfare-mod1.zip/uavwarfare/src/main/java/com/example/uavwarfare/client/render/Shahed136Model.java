package com.example.uavwarfare.client.render;

import com.example.uavwarfare.entity.Shahed136Entity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

/** Дельта-крыло (ступенчатые срезы), законцовки-шайбы, фюзеляж с радиопрозрачным носом, толкающий винт сзади. */
@Environment(EnvType.CLIENT)
public class Shahed136Model extends UavModel<Shahed136Entity> {
    public Shahed136Model() {
        cube(-2.5f, -2.5f, -28f, 5, 5, 8);        // нос
        cube(-3.5f, -3.5f, -20f, 7, 7, 38);       // фюзеляж
        for (int i = 0; i < 8; i++) {              // дельта: ширина растёт к корме
            float span = 6f + i * 4.8f;
            cube(-span / 2f, 1f, -4f + i * 4f, span, 1f, 4f);
        }
        cube(-21f, -8f, 20f, 1, 9, 8);            // законцовки-шайбы
        cube(20f, -8f, 20f, 1, 9, 8);
        cube(-2f, -6f, 12f, 4, 3, 12);            // гондола двигателя
        cube(-2.5f, -2.5f, 18f, 5, 5, 10);        // хвостовая часть
        propeller(0f, -3f, 29f);                  // толкающий винт
    }
}

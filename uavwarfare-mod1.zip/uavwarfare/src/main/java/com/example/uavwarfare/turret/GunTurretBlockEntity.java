package com.example.uavwarfare.turret;

import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.entity.TracerBulletEntity;
import com.example.uavwarfare.entity.TurretSeatEntity;
import com.example.uavwarfare.network.UavNetworking;
import com.example.uavwarfare.registry.ModBlockEntities;
import com.example.uavwarfare.registry.ModEntities;
import net.fabricmc.fabric.api.block.entity.BlockEntityClientSerializable;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Tickable;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.UUID;

public class GunTurretBlockEntity extends BlockEntity implements Tickable, BlockEntityClientSerializable {
    private int ammo, cooldown, sinceShot;
    private float heat;
    private boolean overheated;
    private UUID operator, seat;
    // клиент (анимация)
    public float recoil, prevRecoil, lastYaw, lastPitch;

    public GunTurretBlockEntity() { super(ModBlockEntities.TURRET); }
    public UUID getOperator() { return operator; }

    public void load(ItemStack s, PlayerEntity p) {
        UavConfigHolder c = new UavConfigHolder();
        int room = c.cap - ammo;
        if (room <= 0) return;
        int items = Math.min(s.getCount(), Math.max(1, room / c.per));
        ammo = Math.min(c.cap, ammo + items * c.per);
        if (!p.abilities.creativeMode) s.decrement(items);
        p.sendMessage(new TranslatableText("msg.uavwarfare.ammo", ammo), true);
        markDirty();
    }
    private static class UavConfigHolder { int cap = UavConfig.get().ammoCapacity, per = UavConfig.get().ammoPerItem; }

    public void mount(ServerPlayerEntity p) {
        ServerWorld w = (ServerWorld) world;
        if (operator != null && seat != null) {
            Entity s = w.getEntity(seat);
            if (s != null && s.isAlive() && !s.getPassengerList().isEmpty()) { p.sendMessage(new TranslatableText("msg.uavwarfare.turret_busy"), true); return; }
        }
        TurretSeatEntity e = new TurretSeatEntity(ModEntities.SEAT, w);
        e.setPosition(pos.getX() + 0.5, pos.getY() + 0.4, pos.getZ() + 0.5);
        e.setTurretPos(pos);
        w.spawnEntity(e);
        p.startRiding(e, true);
        operator = p.getUuid(); seat = e.getUuid();
        sync(); markDirty();
        PacketByteBuf b = PacketByteBufs.create();
        b.writeBlockPos(pos); b.writeInt(ammo); b.writeFloat(heat); b.writeBoolean(overheated);
        ServerPlayNetworking.send(p, UavNetworking.TURRET_STATE, b);
    }

    /** Выстрел из направления взгляда стрелка (тангаж ограничен). */
    public void tryFire(ServerPlayerEntity p) {
        UavConfig c = UavConfig.get();
        if (cooldown > 0 || overheated) return;
        if (ammo <= 0) { world.playSound(null, pos, SoundEvents.BLOCK_DISPENSER_FAIL, SoundCategory.BLOCKS, 0.6f, 1.6f); cooldown = 10; return; }
        float pitch = MathHelper.clamp(p.pitch, -80f, 12f);
        Vec3d dir = Vec3d.fromPolar(pitch, p.yaw);
        java.util.Random r = new java.util.Random();
        dir = dir.add((r.nextDouble() - 0.5) * c.bulletSpread * 2, (r.nextDouble() - 0.5) * c.bulletSpread * 2, (r.nextDouble() - 0.5) * c.bulletSpread * 2).normalize();
        Vec3d muzzle = Vec3d.ofCenter(pos).add(0, 0.55, 0).add(dir.multiply(1.5));
        ServerWorld w = (ServerWorld) world;
        TracerBulletEntity b = new TracerBulletEntity(ModEntities.TRACER, w);
        b.setOwner(p);
        b.setPosition(muzzle.x, muzzle.y, muzzle.z);
        b.setVelocity(dir.multiply(c.bulletSpeed));
        w.spawnEntity(b);
        ammo--; cooldown = c.fireDelayTicks; sinceShot = 0;
        heat += c.heatPerShot;
        if (heat >= 100f) { heat = 100f; overheated = true; w.playSound(null, pos, SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.BLOCKS, 1f, 1.2f); }
        w.playSound(null, pos, SoundEvents.BLOCK_DISPENSER_LAUNCH, SoundCategory.BLOCKS, 1.2f, 1.9f);
        w.spawnParticles(ParticleTypes.FLAME, muzzle.x, muzzle.y, muzzle.z, 2, 0.03, 0.03, 0.03, 0.01);   // дульное пламя
        w.spawnParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 2, 0.05, 0.05, 0.05, 0.01);
        PacketByteBuf pb = PacketByteBufs.create();
        pb.writeBlockPos(pos);
        for (ServerPlayerEntity n : PlayerLookup.around(w, Vec3d.ofCenter(pos), 64)) ServerPlayNetworking.send(n, UavNetworking.TURRET_SHOT, pb);
    }

    @Override public void tick() {
        if (world == null) return;
        prevRecoil = recoil;
        if (recoil > 0) recoil = Math.max(0f, recoil - 0.15f);
        if (world.isClient) return;
        UavConfig c = UavConfig.get();
        if (cooldown > 0) cooldown--;
        if (++sinceShot > 4) heat = Math.max(0f, heat - c.heatCooling);       // охлаждение ствола
        if (overheated && heat < c.heatRecover) overheated = false;
        if (operator != null) {
            Entity s = seat == null ? null : ((ServerWorld) world).getEntity(seat);
            if (s == null || !s.isAlive() || s.getPassengerList().isEmpty()) { operator = null; seat = null; sync(); markDirty(); return; }
            if (world.getTime() % 3 == 0) {
                PlayerEntity p = world.getPlayerByUuid(operator);
                if (p instanceof ServerPlayerEntity) {
                    PacketByteBuf b = PacketByteBufs.create();
                    b.writeBlockPos(pos); b.writeInt(ammo); b.writeFloat(heat); b.writeBoolean(overheated);
                    ServerPlayNetworking.send((ServerPlayerEntity) p, UavNetworking.TURRET_STATE, b);
                }
            }
        }
    }

    @Override public CompoundTag toTag(CompoundTag t) {
        super.toTag(t); t.putInt("Ammo", ammo); t.putFloat("Heat", heat);
        if (operator != null) t.putUuid("Op", operator);
        return t;
    }
    @Override public void fromTag(BlockState s, CompoundTag t) {
        super.fromTag(s, t); ammo = t.getInt("Ammo"); heat = t.getFloat("Heat");
        operator = t.containsUuid("Op") ? t.getUuid("Op") : null;
    }
    @Override public void fromClientTag(CompoundTag t) { fromTag(getCachedState(), t); }
    @Override public CompoundTag toClientTag(CompoundTag t) { return toTag(t); }
}

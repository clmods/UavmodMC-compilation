#!/usr/bin/env python3
"""Генератор ресурсов: текстуры, модели, lang, рецепты, loot, sounds.json, звуки двигателей (.ogg)."""
import json, os, random, subprocess, zlib, struct
import numpy as np

A = "src/main/resources/assets/uavwarfare"
D = "src/main/resources/data/uavwarfare"
def w(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

# ---------- PNG ----------
def png(path, W, H, px):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    raw = b"".join(b"\x00" + bytes(sum(([*px(x, y)] for x in range(W)), [])) for y in range(H))
    def ch(t, d): c = struct.pack(">I", len(d)) + t + d; return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    open(path, "wb").write(b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 6, 0, 0, 0)) + ch(b"IDAT", zlib.compress(raw)) + ch(b"IEND", b""))

rnd = random.Random(7)
def icon(name, draw, size=16):
    png(f"{A}/textures/item/{name}.png", size, size, draw)

def box(x, y, x0, y0, x1, y1): return x0 <= x < x1 and y0 <= y < y1
def ctrl(x, y):      # пульт: корпус + экран + антенна
    if box(x, y, 3, 4, 13, 14): return (60, 66, 72, 255) if not box(x, y, 5, 6, 11, 10) else (60, 200, 90, 255)
    if box(x, y, 11, 1, 12, 4): return (150, 150, 150, 255)
    if box(x, y, 5, 11, 7, 13) or box(x, y, 9, 11, 11, 13): return (200, 60, 50, 255)
    return (0, 0, 0, 0)
def ew(c):
    def f(x, y):
        if box(x, y, 4, 6, 12, 14): return (50, 54, 60, 255)
        if box(x, y, 7, 1, 9, 6): return c
        if box(x, y, 5, 8, 11, 10): return c
        return (0, 0, 0, 0)
    return f
def delta(x, y):     # шахед: дельта
    row = y - 2
    if 0 <= row < 12 and abs(x - 7.5) <= row * 0.6 + 0.5: return (170, 176, 182, 255)
    return (0, 0, 0, 0)
def straight(x, y):  # лютый: прямое крыло
    if box(x, y, 1, 6, 15, 8): return (170, 176, 182, 255)
    if box(x, y, 7, 3, 9, 13): return (150, 156, 162, 255)
    if box(x, y, 5, 12, 11, 13): return (150, 156, 162, 255)
    return (0, 0, 0, 0)
def ammo(x, y):
    if box(x, y, 5, 3, 11, 13): return (200, 160, 50, 255) if y > 6 else (230, 90, 30, 255)
    return (0, 0, 0, 0)
icon("controller", ctrl); icon("ew_kit_ready", ew((80, 220, 255, 255))); icon("ew_kit_cooldown", ew((90, 90, 90, 255)))
icon("afl196", straight); icon("shahed136", delta); icon("tracer_ammo", ammo)
def steel(base):
    def f(x, y):
        n = rnd.randint(-8, 8); return (base[0] + n, base[1] + n, base[2] + n, 255)
    return f
png(f"{A}/textures/block/launcher.png", 16, 16, steel((90, 98, 90)))
png(f"{A}/textures/block/gun_turret.png", 16, 16, steel((60, 64, 70)))
png(f"{A}/textures/entity/turret.png", 64, 64, steel((55, 60, 55)))
def hull(base, stripe):
    def f(x, y):
        n = rnd.randint(-6, 6)
        if y % 32 == 0 or x % 64 == 0: return (base[0] - 40, base[1] - 40, base[2] - 40, 255)   # «панельные линии»
        if box(x, y, 0, 0, 256, 4) and stripe: return stripe + (255,)
        return (base[0] + n, base[1] + n, base[2] + n, 255)
    return f
png(f"{A}/textures/entity/shahed136.png", 256, 256, hull((176, 182, 188), None))
png(f"{A}/textures/entity/afl196.png", 256, 256, hull((150, 158, 165), (40, 90, 200)))
for i in range(4):
    png(f"{A}/textures/particle/jam_{i}.png", 8, 8, lambda x, y, i=i: (90, 230, 255, 255) if abs(x - 3.5) + abs(y - 3.5) <= 1 + i * 0.9 and (x + y + i) % 2 == 0 else (0, 0, 0, 0))
w(f"{A}/particles/jam.json", {"textures": [f"uavwarfare:jam_{i}" for i in range(4)]})

# ---------- модели ----------
def el(f, t, tex="#all"): return {"from": f, "to": t, "faces": {d: {"texture": tex} for d in ["north", "south", "east", "west", "up", "down"]}}
w(f"{A}/models/block/launcher.json", {"textures": {"all": "uavwarfare:block/launcher", "particle": "uavwarfare:block/launcher"},
    "elements": [el([0, 0, 0], [16, 2, 16]), el([6, 2, 0], [10, 4, 16]), el([5, 4, 0], [11, 5, 3]), el([5, 4, 13], [11, 5, 16])]})
w(f"{A}/models/block/gun_turret.json", {"textures": {"all": "uavwarfare:block/gun_turret", "particle": "uavwarfare:block/gun_turret"},
    "elements": [el([2, 0, 2], [14, 3, 14]), el([6, 3, 6], [10, 11, 10])]})
w(f"{A}/models/item/launcher.json", {"parent": "uavwarfare:block/launcher"})
w(f"{A}/models/item/gun_turret.json", {"parent": "uavwarfare:block/gun_turret"})
for n in ["controller", "afl196", "shahed136", "tracer_ammo", "ew_kit_ready", "ew_kit_cooldown"]:
    w(f"{A}/models/item/{n}.json", {"parent": "item/generated", "textures": {"layer0": f"uavwarfare:item/{n}"}})
w(f"{A}/models/item/ew_kit.json", {"parent": "item/generated", "textures": {"layer0": "uavwarfare:item/ew_kit_cooldown"},
    "overrides": [{"predicate": {"uavwarfare:ready": 1}, "model": "uavwarfare:item/ew_kit_ready"}]})
w(f"{A}/blockstates/launcher.json", {"variants": {f"facing={f}": {"model": "uavwarfare:block/launcher", "y": y} for f, y in [("north", 0), ("east", 90), ("south", 180), ("west", 270)]}})
w(f"{A}/blockstates/gun_turret.json", {"variants": {"": {"model": "uavwarfare:block/gun_turret"}}})

# ---------- sounds.json ----------
w(f"{A}/sounds.json", {n: {"sounds": [{"name": f"uavwarfare:{n}", "stream": False}]} for n in ["afl_engine", "shahed_engine"]})

# ---------- lang ----------
en = {"itemGroup.uavwarfare.main": "UAV Warfare", "item.uavwarfare.controller": "UAV Controller", "item.uavwarfare.ew_kit": "EW Kit",
 "item.uavwarfare.afl196": "AH-196 \"Lyutyi\"", "item.uavwarfare.shahed136": "Shahed-136", "item.uavwarfare.tracer_ammo": "Tracer Ammo",
 "block.uavwarfare.launcher": "UAV Launcher", "block.uavwarfare.gun_turret": "Machine Gun Turret",
 "entity.uavwarfare.afl196": "AH-196 \"Lyutyi\"", "entity.uavwarfare.shahed136": "Shahed-136", "entity.uavwarfare.tracer_bullet": "Tracer Bullet", "entity.uavwarfare.turret_seat": "Turret Seat",
 "screen.uavwarfare.controller": "Tactical Map", "screen.uavwarfare.ew": "EW Kit",
 "gui.uavwarfare.launch": "Launch", "gui.uavwarfare.rth": "Return (RTH)", "gui.uavwarfare.zoom_in": "Zoom +", "gui.uavwarfare.zoom_out": "Zoom -",
 "gui.uavwarfare.status.0": "On ground", "gui.uavwarfare.status.1": "In flight", "gui.uavwarfare.status.2": "Shot down", "gui.uavwarfare.status.3": "Empty", "gui.uavwarfare.status.4": "No link",
 "gui.uavwarfare.ew_auto": "Mode: AUTO", "gui.uavwarfare.ew_manual": "Mode: MANUAL", "gui.uavwarfare.ew_jam": "Jam", "gui.uavwarfare.ew_ready": "READY", "gui.uavwarfare.ew_cd": "Cooldown: %s s",
 "msg.uavwarfare.linked": "Launcher linked", "msg.uavwarfare.unlinked": "Launcher unlinked", "msg.uavwarfare.link_full": "Max 5 launchers linked",
 "msg.uavwarfare.launcher_busy": "Launcher is busy", "msg.uavwarfare.not_in_flight": "Selected drone is not in flight", "msg.uavwarfare.no_signal": "No signal: drone is farther than 60 blocks",
 "msg.uavwarfare.out_of_range": "Waypoint is outside the allowed boundary", "msg.uavwarfare.ew_cooldown": "EW on cooldown: %s s", "msg.uavwarfare.ew_manual_hint": "Manual mode: pick a target in the GUI (right-click)",
 "msg.uavwarfare.ammo": "Ammo: %s", "msg.uavwarfare.turret_busy": "Turret is occupied"}
ru = {"itemGroup.uavwarfare.main": "UAV Warfare", "item.uavwarfare.controller": "Пульт управления БПЛА", "item.uavwarfare.ew_kit": "Комплект РЭБ",
 "item.uavwarfare.afl196": "AH-196 «Лютый»", "item.uavwarfare.shahed136": "Shahed-136", "item.uavwarfare.tracer_ammo": "Трассирующие патроны",
 "block.uavwarfare.launcher": "Пусковая установка БПЛА", "block.uavwarfare.gun_turret": "Пулемётная турель",
 "entity.uavwarfare.afl196": "AH-196 «Лютый»", "entity.uavwarfare.shahed136": "Shahed-136", "entity.uavwarfare.tracer_bullet": "Трассирующая пуля", "entity.uavwarfare.turret_seat": "Кресло турели",
 "screen.uavwarfare.controller": "Тактическая карта", "screen.uavwarfare.ew": "Комплект РЭБ",
 "gui.uavwarfare.launch": "Запуск", "gui.uavwarfare.rth": "Вернуть (RTH)", "gui.uavwarfare.zoom_in": "Масштаб +", "gui.uavwarfare.zoom_out": "Масштаб -",
 "gui.uavwarfare.status.0": "На земле", "gui.uavwarfare.status.1": "В полёте", "gui.uavwarfare.status.2": "Сбит", "gui.uavwarfare.status.3": "Пусто", "gui.uavwarfare.status.4": "Нет связи",
 "gui.uavwarfare.ew_auto": "Режим: АВТО", "gui.uavwarfare.ew_manual": "Режим: РУЧНОЙ", "gui.uavwarfare.ew_jam": "Заглушить", "gui.uavwarfare.ew_ready": "ГОТОВ", "gui.uavwarfare.ew_cd": "Перезарядка: %s с",
 "msg.uavwarfare.linked": "Установка привязана", "msg.uavwarfare.unlinked": "Установка отвязана", "msg.uavwarfare.link_full": "Максимум 5 установок",
 "msg.uavwarfare.launcher_busy": "Установка занята", "msg.uavwarfare.not_in_flight": "Выбранный дрон не в полёте", "msg.uavwarfare.no_signal": "Нет связи: дрон дальше 60 блоков",
 "msg.uavwarfare.out_of_range": "Точка за допустимой границей", "msg.uavwarfare.ew_cooldown": "РЭБ перезаряжается: %s с", "msg.uavwarfare.ew_manual_hint": "Ручной режим: выберите цель в GUI (ПКМ)",
 "msg.uavwarfare.ammo": "Патронов: %s", "msg.uavwarfare.turret_busy": "Турель занята"}
w(f"{A}/lang/en_us.json", en); w(f"{A}/lang/ru_ru.json", ru)

# ---------- рецепты / лут ----------
def I(i): return {"item": i}
def shaped(name, pat, key, res, n=1):
    w(f"{D}/recipes/{name}.json", {"type": "minecraft:crafting_shaped", "pattern": pat, "key": {k: I(v) for k, v in key.items()}, "result": {"item": f"uavwarfare:{res}", "count": n}})
M = "minecraft:"
shaped("controller", [" C ", "IRI", "IGI"], {"C": M+"compass", "I": M+"iron_ingot", "R": M+"redstone", "G": M+"glass_pane"}, "controller")
shaped("launcher", ["I I", "IPI", "BBB"], {"I": M+"iron_ingot", "P": M+"piston", "B": M+"iron_block"}, "launcher")
shaped("afl196", ["IFI", "TBT", "IRI"], {"I": M+"iron_ingot", "F": M+"feather", "T": M+"tnt", "B": M+"iron_block", "R": M+"redstone"}, "afl196")
shaped("shahed136", ["IFI", "TBT", " R "], {"I": M+"iron_ingot", "F": M+"feather", "T": M+"tnt", "B": M+"iron_block", "R": M+"redstone"}, "shahed136")
shaped("ew_kit", ["RER", "ICI", "IBI"], {"R": M+"redstone", "E": M+"end_rod", "C": M+"comparator", "I": M+"iron_ingot", "B": M+"redstone_block"}, "ew_kit")
shaped("gun_turret", ["III", "DPD", "BBB"], {"I": M+"iron_ingot", "D": M+"dispenser", "P": M+"piston", "B": M+"iron_block"}, "gun_turret")
w(f"{D}/recipes/tracer_ammo.json", {"type": "minecraft:crafting_shapeless", "ingredients": [I(M+"gunpowder"), I(M+"iron_ingot"), I(M+"iron_ingot")], "result": {"item": "uavwarfare:tracer_ammo", "count": 16}})
for b in ["launcher", "gun_turret"]:
    w(f"{D}/loot_tables/blocks/{b}.json", {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"uavwarfare:{b}"}], "conditions": [{"condition": "minecraft:survives_explosion"}]}]})

# ---------- звук двигателей (mono 44.1 kHz, петля 5 c, бесшовная) ----------
SR, T = 44100, 5.0
N = int(SR * T); t = np.arange(N) / SR
def periodic_noise(seed, lo, hi):
    """Шум, периодичный ровно на N отсчётов (через irfft) → шов петли невидим."""
    r = np.random.RandomState(seed); spec = np.zeros(N // 2 + 1, complex)
    f = np.fft.rfftfreq(N, 1 / SR); m = (f >= lo) & (f <= hi)
    spec[m] = r.randn(m.sum()) + 1j * r.randn(m.sum())
    x = np.fft.irfft(spec, N); return x / np.abs(x).max()
def save(name, x):
    x = x / np.abs(x).max() * 0.85
    pcm = (x * 32767).astype("<i2").tobytes()
    open("/tmp/_e.raw", "wb").write(pcm)
    out = f"{A}/sounds/{name}.ogg"; os.makedirs(os.path.dirname(out), exist_ok=True)
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "s16le", "-ar", str(SR), "-ac", "1", "-i", "/tmp/_e.raw", "-c:a", "libvorbis", "-q:a", "5", out], check=True)
# AH-196: высокочастотный гул ≈ 190 Гц (целое число периодов за 5 с), чистые гармоники + лёгкая амплитудная пульсация
f0 = 190.0
afl = sum(a * np.sin(2 * np.pi * f0 * k * t + k) for k, a in [(1, 1.0), (2, 0.6), (3, 0.45), (4, 0.3), (6, 0.18)])
afl = afl * (1 + 0.08 * np.sin(2 * np.pi * 6 * t)) + 0.15 * periodic_noise(1, 800, 5000)
save("afl_engine", afl)
# Shahed-136: низкий «газонокосилочный» рёв ≈ 70 Гц, пила + сильная АМ 35 Гц + шум
g0 = 70.0
saw = sum(np.sin(2 * np.pi * g0 * k * t) / k for k in range(1, 16))
sha = saw * (0.75 + 0.25 * np.sign(np.sin(2 * np.pi * 35 * t))) * (1 + 0.1 * np.sin(2 * np.pi * 0.8 * t)) + 0.35 * periodic_noise(2, 150, 3500)
save("shahed_engine", sha)
print("assets ok")

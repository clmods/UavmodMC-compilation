package com.example.uavwarfare;

import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.entity.TurretSeatEntity;
import com.example.uavwarfare.network.UavNetworking;
import com.example.uavwarfare.registry.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;

public class UavWarfare implements ModInitializer {
    public static final String MODID = "uavwarfare";

    public static Identifier id(String path) { return new Identifier(MODID, path); }

    @Override
    public void onInitialize() {
        UavConfig.load();
        ModSounds.register();
        ModParticles.register();
        ModBlocks.register();
        ModItems.register();
        ModEntities.register();
        ModBlockEntities.register();
        UavNetworking.registerServer();

        // Пока игрок сидит за пулемётом, ЛКМ не должна ломать блоки / бить сущностей.
        AttackBlockCallback.EVENT.register((p, w, h, pos, dir) ->
                p.getVehicle() instanceof TurretSeatEntity ? ActionResult.FAIL : ActionResult.PASS);
        AttackEntityCallback.EVENT.register((p, w, h, e, hit) ->
                p.getVehicle() instanceof TurretSeatEntity ? ActionResult.FAIL : ActionResult.PASS);
    }
}

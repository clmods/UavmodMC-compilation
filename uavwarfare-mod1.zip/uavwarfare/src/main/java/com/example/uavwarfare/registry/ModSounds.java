package com.example.uavwarfare.registry;

import com.example.uavwarfare.UavWarfare;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.registry.Registry;

public class ModSounds {
    public static SoundEvent AFL_ENGINE, SHAHED_ENGINE;
    private static SoundEvent reg(String n) {
        return Registry.register(Registry.SOUND_EVENT, UavWarfare.id(n), new SoundEvent(UavWarfare.id(n)));
    }
    public static void register() { AFL_ENGINE = reg("afl_engine"); SHAHED_ENGINE = reg("shahed_engine"); }
}

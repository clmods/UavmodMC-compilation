package com.example.uavwarfare.ew;

import com.example.uavwarfare.entity.AbstractUavEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.List;

/** Сканирует небо в радиусе. Фильтра «свой/чужой» нет — глушатся все дроны. */
public final class EwScanner {
    private EwScanner() {}
    public static List<AbstractUavEntity> scan(World w, Vec3d c, double r) {
        return w.getEntitiesByClass(AbstractUavEntity.class, new Box(c, c).expand(r),
                e -> e.isAlive() && e.squaredDistanceTo(c) <= r * r);
    }
}

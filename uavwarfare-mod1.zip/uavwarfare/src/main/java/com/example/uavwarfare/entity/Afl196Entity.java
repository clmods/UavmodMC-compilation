package com.example.uavwarfare.entity;

import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.registry.ModSounds;
import com.example.uavwarfare.uav.UavType;
import net.minecraft.entity.EntityType;
import net.minecraft.sound.SoundEvent;
import net.minecraft.world.World;

/** AH-196 «Лютый»: прямое крыло, тянущий винт спереди, быстрее и прочнее, высокий тон двигателя. */
public class Afl196Entity extends AbstractUavEntity {
    public Afl196Entity(EntityType<? extends Afl196Entity> t, World w) { super(t, w); }
    @Override public UavType type() { return UavType.AFL196; }
    @Override public float maxHealth() { return UavConfig.get().aflHealth; }
    @Override public float maxSpeed() { return UavConfig.get().aflSpeed; }
    @Override public float maxYawRate() { return 4.0f; }
    @Override public float propSpin() { return 70f; }
    @Override public SoundEvent engineSound() { return ModSounds.AFL_ENGINE; }
}

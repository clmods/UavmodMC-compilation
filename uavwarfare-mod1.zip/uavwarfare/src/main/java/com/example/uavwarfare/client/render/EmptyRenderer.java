package com.example.uavwarfare.client.render;

import com.example.uavwarfare.UavWarfare;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public class EmptyRenderer extends EntityRenderer<Entity> {
    public EmptyRenderer(EntityRenderDispatcher d) { super(d); }
    @Override public Identifier getTexture(Entity e) { return UavWarfare.id("textures/entity/afl196.png"); }
    @Override public void render(Entity e, float y, float td, MatrixStack m, VertexConsumerProvider v, int l) {}
}

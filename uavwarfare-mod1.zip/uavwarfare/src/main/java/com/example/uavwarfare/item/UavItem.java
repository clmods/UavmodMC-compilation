package com.example.uavwarfare.item;

import com.example.uavwarfare.uav.UavType;
import net.minecraft.item.Item;

public class UavItem extends Item {
    public final UavType type;
    public UavItem(UavType type, Settings s) { super(s); this.type = type; }
}

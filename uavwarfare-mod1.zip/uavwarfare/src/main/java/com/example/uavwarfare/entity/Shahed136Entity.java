package com.example.uavwarfare.entity;

import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.registry.ModSounds;
import com.example.uavwarfare.uav.UavType;
import net.minecraft.entity.EntityType;
import net.minecraft.sound.SoundEvent;
import net.minecraft.world.World;

/** Shahed-136: дельта-крыло, толкающий винт сзади, медленнее; низкий «газонокосилочный» рёв. */
public class Shahed136Entity extends AbstractUavEntity {
    public Shahed136Entity(EntityType<? extends Shahed136Entity> t, World w) { super(t, w); }
    @Override public UavType type() { return UavType.SHAHED136; }
    @Override public float maxHealth() { return UavConfig.get().shahedHealth; }
    @Override public float maxSpeed() { return UavConfig.get().shahedSpeed; }
    @Override public float maxYawRate() { return 2.5f; }
    @Override public float propSpin() { return 45f; }
    @Override public SoundEvent engineSound() { return ModSounds.SHAHED_ENGINE; }
    /** Лёгкое «дребезжание» тона — характерный надрыв двухтактника. */
    @Override public float soundPitchWobble() { return 0.02f * (float) Math.sin(age * 0.6); }
}

package com.example.uavwarfare.client.screen;

import com.example.uavwarfare.config.UavConfig;
import com.example.uavwarfare.entity.AbstractUavEntity;
import com.example.uavwarfare.ew.EwDeviceItem;
import com.example.uavwarfare.ew.EwMode;
import com.example.uavwarfare.network.UavNetworking;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.TranslatableText;

import java.util.ArrayList;
import java.util.List;

/** Мини-GUI РЭБ: режим AUTO/MANUAL и список дронов в радиусе (ручной выбор цели → «Заглушить»). */
@Environment(EnvType.CLIENT)
public class EwDeviceScreen extends Screen {
    private List<AbstractUavEntity> list = new ArrayList<>();
    private int sel = -1;
    private ButtonWidget modeBtn;
    public EwDeviceScreen() { super(new TranslatableText("screen.uavwarfare.ew")); }
    @Override public boolean isPauseScreen() { return false; }

    private ItemStack stack() { return EwDeviceItem.find(client.player); }

    @Override protected void init() {
        int x = width / 2 - 100, y = height / 2 - 60;
        modeBtn = addButton(new ButtonWidget(x, y, 200, 20, modeText(), b -> {
            ItemStack s = stack(); if (s == null) return;
            boolean manual = EwDeviceItem.getMode(s) == EwMode.AUTO;
            EwDeviceItem.setMode(s, manual ? EwMode.MANUAL : EwMode.AUTO);   // локально для мгновенного отклика
            PacketByteBuf p = PacketByteBufs.create(); p.writeBoolean(manual);
            ClientPlayNetworking.send(UavNetworking.EW_MODE, p);
            b.setMessage(modeText());
        }));
        addButton(new ButtonWidget(x, y + 112, 200, 20, new TranslatableText("gui.uavwarfare.ew_jam"), b -> {
            if (sel >= 0 && sel < list.size()) {
                PacketByteBuf p = PacketByteBufs.create(); p.writeUuid(list.get(sel).getUuid());
                ClientPlayNetworking.send(UavNetworking.EW_JAM, p);
            }
        }));
    }

    private net.minecraft.text.Text modeText() {
        ItemStack s = client == null ? null : stack();
        return new TranslatableText(s != null && EwDeviceItem.getMode(s) == EwMode.MANUAL ? "gui.uavwarfare.ew_manual" : "gui.uavwarfare.ew_auto");
    }

    @Override public void tick() {
        double r = UavConfig.get().ewRadius;
        list = client.world.getEntitiesByClass(AbstractUavEntity.class, client.player.getBoundingBox().expand(r), e -> e.isAlive() && e.squaredDistanceTo(client.player) <= r * r);
        if (sel >= list.size()) sel = -1;
    }

    @Override public void render(MatrixStack ms, int mx, int my, float td) {
        renderBackground(ms);
        int x = width / 2 - 100, y = height / 2 - 60;
        ItemStack s = stack();
        long now = client.world.getTime();
        boolean ready = s != null && EwDeviceItem.ready(s, now);
        drawCenteredText(ms, textRenderer, title, width / 2, y - 14, 0xFFFFFF);
        String st = ready ? new TranslatableText("gui.uavwarfare.ew_ready").getString()
                : new TranslatableText("gui.uavwarfare.ew_cd", s == null ? 0 : (EwDeviceItem.cooldownUntil(s) - now) / 20 + 1).getString();
        drawCenteredText(ms, textRenderer, new net.minecraft.text.LiteralText(st), width / 2, y + 24, ready ? 0xFF55FF55 : 0xFFFF5555);
        fill(ms, x, y + 38, x + 200, y + 108, 0xAA000000);
        for (int i = 0; i < Math.min(6, list.size()); i++) {
            AbstractUavEntity e = list.get(i);
            String line = (e.type().ordinal() == 0 ? "AH-196" : "Shahed-136") + "  " + (int) e.distanceTo(client.player) + " m";
            textRenderer.drawWithShadow(ms, line, x + 6, y + 42 + i * 11, i == sel ? 0xFF55FF55 : 0xFFFFFFFF);
        }
        super.render(ms, mx, my, td);
    }

    @Override public boolean mouseClicked(double mx, double my, int btn) {
        if (super.mouseClicked(mx, my, btn)) return true;
        int x = width / 2 - 100, y = height / 2 - 60;
        if (mx >= x && mx < x + 200 && my >= y + 42) { int i = (int) ((my - y - 42) / 11); if (i >= 0 && i < Math.min(6, list.size())) { sel = i; return true; } }
        return false;
    }
}

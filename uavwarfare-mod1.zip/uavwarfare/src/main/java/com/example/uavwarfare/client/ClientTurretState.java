package com.example.uavwarfare.client;

import net.minecraft.util.math.BlockPos;

public final class ClientTurretState {
    public static BlockPos pos; public static int ammo; public static float heat; public static boolean overheated;
    public static int lastUpdate;
    private ClientTurretState() {}
}
